<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit;
}
require_once "../config/database.php";
// Ambil data destinasi dari DB
$stmt = $pdo->query("SELECT nama, deskripsi, latitude, longitude FROM destinasi");
$destinasi = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Peta Interaktif - Pariwita</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://unpkg.com/leaflet/dist/leaflet.css" />
  <script src="https://unpkg.com/leaflet/dist/leaflet.js"></script>
  <style>
    #map { height: 600px; width: 100%; border-radius: 10px; }
  </style>
</head>
<body class="bg-light">
<div class="container mt-4">
  <h2 class="mb-3">Peta Interaktif Destinasi Wisata</h2>
  <div id="map"></div>
  <a href="index.php" class="btn btn-secondary mt-3">Kembali</a>
</div>

<script>
  // Data destinasi dari PHP → JavaScript
  var destinasi = <?php echo json_encode($destinasi); ?>;

  // Inisialisasi peta
  var map = L.map('map').setView([-2.9263, 132.3001], 12); // default Fakfak

  // Tambahkan layer OpenStreetMap
  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '© OpenStreetMap contributors'
  }).addTo(map);

  // Fungsi haversine untuk hitung jarak (km)
  function getDistance(lat1, lon1, lat2, lon2) {
    var R = 6371; // radius bumi km
    var dLat = (lat2-lat1) * Math.PI/180;
    var dLon = (lon2-lon1) * Math.PI/180;
    var a = Math.sin(dLat/2) * Math.sin(dLat/2) +
            Math.cos(lat1*Math.PI/180) * Math.cos(lat2*Math.PI/180) *
            Math.sin(dLon/2) * Math.sin(dLon/2);
    var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    return R * c;
  }

  // Tambahkan marker untuk destinasi, nanti update popup kalau user ketemu
  var markers = [];
  destinasi.forEach(function(d) {
    var marker = L.marker([parseFloat(d.latitude), parseFloat(d.longitude)]).addTo(map);
    marker.bindPopup("<h6>" + d.nama + "</h6><p>" + d.deskripsi + "</p>");
    markers.push({ marker: marker, data: d });
  });

  // Tambahkan marker lokasi user
  if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(function(pos) {
      var userLat = pos.coords.latitude;
      var userLng = pos.coords.longitude;

      var userMarker = L.marker([userLat, userLng], {
        icon: L.icon({
          iconUrl: 'https://cdn-icons-png.flaticon.com/512/64/64113.png',
          iconSize: [32, 32]
        })
      }).addTo(map);
      userMarker.bindPopup("Lokasi Anda").openPopup();

      // Update setiap popup destinasi dengan jarak
      markers.forEach(function(m) {
        var jarak = getDistance(userLat, userLng, parseFloat(m.data.latitude), parseFloat(m.data.longitude));
        var newPopup = "<h6>" + m.data.nama + "</h6>" +
                       "<p>" + m.data.deskripsi + "</p>" +
                       "<p><b>Jarak dari Anda:</b> " + jarak.toFixed(2) + " km</p>";
        m.marker.bindPopup(newPopup);
      });
    });
  } else {
    alert("Geolocation tidak didukung browser ini.");
  }
</script>
</body>
</html>
