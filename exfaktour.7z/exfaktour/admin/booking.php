<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit;
}
require_once "../config/database.php";

$stmt = $pdo->query("SELECT * FROM booking ORDER BY id_booking DESC");
$booking = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Kelola Booking - Pariwita</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container mt-4">
  <h2>Kelola Booking / Reservasi</h2>
  <table class="table table-bordered table-striped">
    <thead class="table-dark">
      <tr>
        <th>No</th>
        <th>Nama</th>
        <th>Email</th>
        <th>Destinasi</th>
        <th>Jumlah Tiket</th>
        <th>Tanggal</th>
        <th>Status</th>
        <th>Aksi</th>
      </tr>
    </thead>
    <tbody>
      <?php $no=1; foreach ($booking as $row): ?>
      <tr>
        <td><?= $no++ ?></td>
        <td><?= htmlspecialchars($row['nama']) ?></td>
        <td><?= htmlspecialchars($row['email']) ?></td>
        <td><?= htmlspecialchars($row['destinasi']) ?></td>
        <td><?= $row['jumlah_tiket'] ?></td>
        <td><?= $row['tanggal'] ?></td>
        <td><?= $row['status'] ?></td>
        <td>
          <a href="booking_update.php?id=<?= $row['id_booking'] ?>&status=Dikonfirmasi" 
             class="btn btn-success btn-sm">Konfirmasi</a>
          <a href="booking_update.php?id=<?= $row['id_booking'] ?>&status=Batal" 
             class="btn btn-danger btn-sm">Batal</a>
        </td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
  <a href="index.php" class="btn btn-secondary">Kembali</a>
</div>
</body>
</html>
