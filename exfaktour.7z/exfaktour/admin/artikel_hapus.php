<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit;
}
require_once "../config/database.php";

$id = $_GET['id'] ?? '';
if ($id) {
    $stmt = $pdo->prepare("DELETE FROM artikel WHERE id_artikel=?");
    $stmt->execute([$id]);
}
header("Location: artikel.php");
exit;
?>
