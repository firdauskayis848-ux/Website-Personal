<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit;
}
require_once "../config/database.php";

$id = $_GET['id'] ?? '';
$nama = $deskripsi = $lokasi = $tiket = $jam_buka = $gambar = "";
$latitude = $longitude = $whatsapp =""; // ✅ cara yang benar

if ($id) {
    $stmt = $pdo->prepare("SELECT * FROM destinasi WHERE id_destinasi=?");
    $stmt->execute([$id]);
    $data = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($data) {
        $nama = $data['nama'];
        $deskripsi = $data['deskripsi'];
        $lokasi = $data['lokasi'];
        $tiket = $data['tiket'];
        $jam_buka = $data['jam_buka'];
        $gambar = $data['gambar'];
        $latitude = $data['latitude'];
        $longitude = $data['longitude'];
        $whatsapp = $data['whatsapp'];
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nama = $_POST['nama'];
    $lokasi = $_POST['lokasi'];
    $tiket = $_POST['tiket'];
    $jam_buka = $_POST['jam_buka'];
    $whatsapp= $_POST['whatsapp'];
    

    // upload gambar
    if ($_FILES['gambar']['name']) {
        $fileName = time() . "_" . $_FILES['gambar']['name'];
        move_uploaded_file($_FILES['gambar']['tmp_name'], "../uploads/" . $fileName);
    } else {
        $fileName = $gambar;
    }

   if ($id) {
    // UPDATE
    $stmt = $pdo->prepare("UPDATE destinasi SET nama=?, lokasi=?, deskripsi=?, jam_buka=?, latitude=?, longitude=?, gambar=?, whatsapp=? WHERE id_destinasi=?");
    $stmt->execute([$nama, $lokasi, $deskripsi, $jam_buka, $latitude, $longitude, $fileName, $whatsapp, $id]);
} else {
    // INSERT
    $stmt = $pdo->prepare("INSERT INTO destinasi (nama, lokasi, deskripsi, jam_buka, latitude, longitude, gambar, whatsapp) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([$nama, $lokasi, $deskripsi, $jam_buka, $latitude, $longitude, $fileName, $whatsapp]);
}
    header("Location: destinasi.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title><?= $id ? 'Edit' : 'Tambah' ?> Destinasi</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container mt-4">
  <h2><?= $id ? 'Edit' : 'Tambah' ?> Destinasi Wisata</h2>
  <form method="POST" enctype="multipart/form-data">
    <div class="mb-3">
      <label>Nama Destinasi</label>
      <input type="text" name="nama" class="form-control" value="<?= htmlspecialchars($nama) ?>" required>
    </div>
    <div class="mb-3">
      <label>Lokasi</label>
      <input type="text" name="lokasi" class="form-control" value="<?= htmlspecialchars($lokasi) ?>" required>
    </div>
    <div class="mb-3">
      <label>Tiket</label>
      <input type="text" name="tiket" class="form-control" value="<?= htmlspecialchars($tiket) ?>" required>
    </div>
    <div class="mb-3">
    <label>WhatsApp</label>
    <input type="text" name="whatsapp" class="form-control" placeholder="Masukkan nomor/WA link" value="<?= htmlspecialchars($data['whatsapp'] ?? '') ?>">
</div>
    <div class="mb-3">
      <label>Jam Buka</label>
      <input type="text" name="jam_buka" class="form-control" value="<?= htmlspecialchars($jam_buka) ?>" required>
    </div>
    <div class="mb-3">
  <label>Latitude</label>
  <input type="text" name="latitude" class="form-control" value="<?= htmlspecialchars($latitude) ?>" required>
</div>
<div class="mb-3">
  <label>Longitude</label>
  <input type="text" name="longitude" class="form-control" value="<?= htmlspecialchars($longitude) ?>" required>
</div>

    <div class="mb-3">
      <label>gambar</label>
      <input type="file" name="gambar" class="form-control">
      <?php if ($gambar): ?>
        <img src="../admin/uploads/<?= $gambar ?>" width="120" class="mt-2">
      <?php endif; ?>
    </div>
    <button class="btn btn-success"><?= $id ? 'Update' : 'Simpan' ?></button>
    <a href="destinasi.php" class="btn btn-secondary">Kembali</a>
  </form>
</div>
<div class="card-footer text-center text-muted py-2">
                &copy; <?= date('Y') ?> EXFAKTOUR. Semua Hak Dilindungi.
            </div>
</body>
</html>
