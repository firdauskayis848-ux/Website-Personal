<?php
session_start();
require_once "../config/database.php";

if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit;
}

$id = $_GET['id'];
$stmt = $pdo->prepare("SELECT * FROM artikel WHERE id_artikel=?");
$stmt->execute([$id]);
$a = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$a) {
    die("Data artikel tidak ditemukan!");
}

// =============================
// UPDATE DATA
// =============================
if (isset($_POST['update'])) {
    $judul   = $_POST['judul'];
    $isi     = $_POST['isi'];

    $gambar = $a['gambar']; // default lama
    if (!empty($_FILES['gambar']['name'])) {
        $gambar = time() . "_" . $_FILES['gambar']['name'];
        move_uploaded_file($_FILES['gambar']['tmp_name'], "../admin/uploads/" . $gambar);
    }

    $stmt = $pdo->prepare("UPDATE artikel SET judul=?, isi=?, gambar=? WHERE id_artikel=?");
    $stmt->execute([$judul, $isi, $gambar, $id]);

    header("Location: artikel.php");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Artikel - Admin Pariwita</title>
</head>
<body>
    <h1>Edit Artikel / Berita Wisata</h1>
    <form method="POST" enctype="multipart/form-data">
        <input type="text" name="judul" value="<?= $a['judul'] ?>" required><br>
        <textarea name="isi" rows="5" cols="50"><?= $a['isi'] ?></textarea><br>
        <p>Gambar lama: 
            <?php if ($a['gambar']): ?>
                <img src="..admin/uploads/<?= $a['gambar'] ?>" width="100">
            <?php endif; ?>
        </p>
        <input type="file" name="gambar"><br>
        <button type="submit" name="update">Update</button>
    </form>
</body>
</html>
