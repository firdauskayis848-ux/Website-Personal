<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit;
}
require_once "../config/database.php";

$id = $_GET['id'] ?? '';
if ($id) {
    $stmt = $pdo->prepare("DELETE FROM kuliner WHERE id_kuliner=?");
    $stmt->execute([$id]);
}
header("Location: kuliner.php");
exit;
?>
