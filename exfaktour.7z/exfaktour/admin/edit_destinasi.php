<?php
session_start();
require_once "../config/database.php";

if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit;
}

$id = $_GET['id'];
$stmt = $pdo->prepare("SELECT * FROM destinasi WHERE id_destinasi=?");
$stmt->execute([$id]);
$d = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$d) {
    die("Data destinasi tidak ditemukan!");
}

// =============================
// UPDATE DATA
// =============================
if (isset($_POST['update'])) {
    $nama     = $_POST['nama'];
    $lokasi   = $_POST['lokasi'];
    $deskripsi= $_POST['deskripsi'];
    $tiket    = $_POST['tiket'];
    $jam_buka = $_POST['jam_buka'];
    $lat      = $_POST['latitude'];
    $lng      = $_POST['longitude'];

    $gambar = $d['gambar']; // default lama
    if (!empty($_FILES['gambar']['name'])) {
        $gambar = time() . "_" . $_FILES['gambar']['name'];
        move_uploaded_file($_FILES['gambar']['tmp_name'], "../admin/uploads/" . $gambar);
    }

    $stmt = $pdo->prepare("UPDATE destinasi SET nama=?, lokasi=?, deskripsi=?, tiket=?, jam_buka=?, latitude=?, longitude=?, gambar=? WHERE id_destinasi=?");
    $stmt->execute([$nama, $lokasi, $deskripsi, $tiket, $jam_buka, $lat, $lng, $gambar, $id]);

    header("Location: destinasi.php");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Destinasi - Admin Pariwita</title>
</head>
<body>
    <h1>Edit Destinasi Wisata</h1>
    <form method="POST" enctype="multipart/form-data">
        <input type="text" name="nama" value="<?= $d['nama'] ?>" required><br>
        <input type="text" name="lokasi" value="<?= $d['lokasi'] ?>" required><br>
        <textarea name="deskripsi"><?= $d['deskripsi'] ?></textarea><br>
        <input type="number" step="0.01" name="tiket" value="<?= $d['tiket'] ?>"><br>
        <input type="text" name="jam_buka" value="<?= $d['jam_buka'] ?>"><br>
        <input type="text" name="latitude" value="<?= $d['latitude'] ?>"><br>
        <input type="text" name="longitude" value="<?= $d['longitude'] ?>"><br>
        <p>Gambar lama: 
            <?php if ($d['gambar']): ?>
                <img src="../assets/img/<?= $d['gambar'] ?>" width="100">
            <?php endif; ?>
        </p>
        <input type="file" name="gambar"><br>
        <button type="submit" name="update">Update</button>
    </form>
    <div class="card-footer text-center text-muted py-2">
                &copy; <?= date('Y') ?> EXFAKTOUR. Semua Hak Dilindungi.
            </div>
</body>
</html>
