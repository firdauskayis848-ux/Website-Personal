<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit;
}

require_once "../config/database.php";

try {
    // Ambil semua data kuliner
    $stmt = $pdo->query("SELECT * FROM kuliner");
    $kuliner = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Terjadi kesalahan database: " . $e->getMessage());
}

// Cari kolom ID
$id_column = null;
if (!empty($kuliner)) {
    $candidates = ['id', 'id_kuliner', 'id_destination', 'id_dest', 'idkuliner'];
    foreach ($candidates as $c) {
        if (array_key_exists($c, $kuliner[0])) {
            $id_column = $c;
            break;
        }
    }

    if (!$id_column) {
        $keys = array_keys($kuliner[0]);
        $id_column = $keys[0];
    }

    // Urutkan descending berdasarkan ID
    usort($kuliner, function ($a, $b) use ($id_column) {
        $av = $a[$id_column] ?? null;
        $bv = $b[$id_column] ?? null;
        if (is_numeric($av) && is_numeric($bv)) {
            return $bv <=> $av;
        }
        return strcmp((string)$bv, (string)$av);
    });
}

// Tentukan kolom foto
$foto_column = null;
if (!empty($kuliner)) {
    $sample = $kuliner[0];
    foreach (['foto', 'gambar', 'image', 'photo'] as $f) {
        if (array_key_exists($f, $sample)) {
            $foto_column = $f;
            break;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <title>Kelola Kuliner</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .table img {
            transition: 0.2s ease;
        }
        .table img:hover {
            transform: scale(1.5);
        }
    </style>
</head>

<body class="bg-light">
<div class="container-fluid mt-4">
    <h2 class="mb-4">Daftar Kuliner</h2>
    <a href="kuliner_form.php" class="btn btn-primary mb-3">+ Tambah Kuliner</a>

    <div class="card shadow">
        <div class="card-body">
            <table class="table table-bordered table-striped align-middle">
                <thead class="table-dark text-center">
                    <tr>
                        <th>#</th>
                        <th>Nama</th>
                        <th>Lokasi</th>
                        <th>Deskripsi</th>
                        <th>Jam Buka</th>
                        <th>Foto</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                <?php if ($kuliner): ?>
                    <?php $no = 1; foreach ($kuliner as $row): ?>
                        <tr>
                            <td class="text-center"><?= $no++ ?></td>
                            <td><?= htmlspecialchars($row['nama'] ?? '—') ?></td>
                            <td><?= htmlspecialchars($row['lokasi'] ?? '—') ?></td>
                            <td><?= htmlspecialchars($row['deskripsi'] ?? '—') ?></td>
                            <td><?= htmlspecialchars($row['jam_buka'] ?? '—') ?></td>
                            <td class="text-center">
                                <?php
                                if ($foto_column && !empty($row[$foto_column])) {
                                    $path = "../uploads/" . $row[$foto_column];
                                    if (file_exists($path)) {
                                        echo '<a href="' . htmlspecialchars($path) . '" target="_blank">
                                                <img src="' . htmlspecialchars($path) . '" width="100" class="rounded shadow">
                                              </a>';
                                    } else {
                                        echo '<span class="text-danger">File tidak ditemukan</span>';
                                    }
                                } else {
                                    echo '<span class="text-muted">Tidak ada foto</span>';
                                }
                                ?>
                            </td>
                            <td class="text-center">
                                <?php
                                $id_val = $row[$id_column] ?? null;
                                if ($id_val !== null) {
                                    $id_enc = urlencode($id_val);
                                    echo '<a href="kuliner_form.php?id=' . $id_enc . '" class="btn btn-sm btn-warning me-1">Edit</a>';
                                    echo '<a href="kuliner_hapus.php?id=' . $id_enc . '" class="btn btn-sm btn-danger" onclick="return confirm(\'Yakin ingin menghapus kuliner ini?\')">Hapus</a>';
                                } else {
                                    echo '<span class="text-muted">ID tidak ditemukan</span>';
                                }
                                ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="7" class="text-center text-muted">Belum ada data kuliner</td>
                    </tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <a href="index.php" class="btn btn-secondary mt-3">Kembali</a>
</div>
</body>
<div class="card-footer text-center text-muted py-2">
                &copy; <?= date('Y') ?> EXFAKTOUR. Semua Hak Dilindungi.
            </div>
</body>
</html>
