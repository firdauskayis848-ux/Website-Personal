<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>EXFAKTOUR</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
  <style>
    body {
      min-height: 100vh;
      display: flex;
    }
    .sidebar {
      width: 250px;
      background: #0d6efd;
      color: white;
      flex-shrink: 0;
    }
    .sidebar a {
      color: white;
      text-decoration: none;
      display: block;
      padding: 12px 20px;
    }
    .sidebar a:hover {
      background: rgba(255, 255, 255, 0.2);
    }
    .content {
      flex-grow: 1;
      padding: 20px;
    }
  </style>
</head>
<body>
  <!-- Sidebar -->
  <div class="sidebar">
    <h4 class="p-3 text-center">EXFAKTOUR</h4>
    <a href="index.php"><i class="bi bi-house"></i> Dashboard</a>
    <a href="destinasi.php"><i class="bi bi-geo-alt"></i> Kelola Destinasi</a>
    <a href="kuliner.php"><i class="bi bi-cup-straw"></i> Kelola Kuliner</a>
    <a href="hotel.php"><i class="bi bi-cup-straw"></i> Kelola Hotel</a>
    <a href="peta.php"><i class="bi bi-map"></i> Peta Interaktif</a>
    <a href="booking.php"><i class="bi bi-ticket-perforated"></i> Booking</a>
    <a href="artikel.php"><i class="bi bi-newspaper"></i> Artikel</a>
    <a href="logout.php" ><i class="text-danger" class="bi bi-box-arrow-right"></i> Logout</a>
  </div>

  <!-- Content -->
  <div class="content">
    <h2>Selamat Datang, <?= $_SESSION['nama_admin'] ?> 🎉</h2>
    <p>Gunakan menu di samping untuk mengelola aplikasi Pariwita.</p>

    <div class="row mt-4">
      <div class="col-md-4">
        <div class="card shadow-sm">
          <div class="card-body">
            <h5 class="card-title"><i class="bi bi-geo-alt text-primary"></i> Destinasi</h5>
            <p class="card-text">Kelola daftar tempat wisata.</p>
            <a href="destinasi.php" class="btn btn-primary">Kelola</a>
          </div>
        </div>
      </div>

      <div class="col-md-4">
        <div class="card shadow-sm">
          <div class="card-body">
            <h5 class="card-title"><i class="bi bi-cup-straw text-warning"></i> Kuliner</h5>
            <p class="card-text">Kelola rekomendasi kuliner lokal.</p>
            <a href="kuliner.php" class="btn btn-warning">Kelola</a>
          </div>
        </div>
      </div>
      <div class="col-md-4">
        <div class="card shadow-sm">
          <div class="card-body">
            <h5 class="card-title"><i class="bi bi-geo-alt text-primary"></i> Hotel</h5>
            <p class="card-text">Kelola rekomendasi hotel.</p>
            <a href="hotel.php" class="btn btn-warning">Kelola</a>
          </div>
        </div>
      </div>

      <div class="col-md-4">
        <div class="card shadow-sm">
          <div class="card-body">
            <h5 class="card-title"><i class="bi bi-newspaper text-success"></i> Artikel</h5>
            <p class="card-text">Kelola berita dan artikel wisata.</p>
            <a href="artikel.php" class="btn btn-success">Kelola</a>
          </div>


        </div>
      </div>
    </div>

<div class="card-footer text-center text-muted py-2">
                &copy; <?= date('Y') ?> EXFAKTOUR. Semua Hak Dilindungi.
</div>
  </div>
</div>
</div>
</div>

</body>

</html>
