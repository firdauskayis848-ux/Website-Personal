<?php

session_start();
require_once "../config/database.php";

$error = "";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $stmt = $pdo->prepare("SELECT * FROM admin WHERE LOWER(username)=LOWER(?)");
    $stmt->execute([$username]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['admin'] = $user['id_admin'];
        $_SESSION['nama_admin'] = $user['nama_lengkap'];
        header("Location: index.php");
        exit;
    } else {
        $error = "Username atau password salah!";
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EXFAKTOUR | Login Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://unpkg.com/lucide@latest"></script>
    <style>
        body {
            background: linear-gradient(135deg, #007bff, #6610f2);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .login-card {
            border: none;
            border-radius: 1rem;
            overflow: hidden;
            box-shadow: 0 8px 25px rgba(0,0,0,0.2);
            animation: fadeIn 0.6s ease-in-out;
        }
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(30px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .brand {
            font-size: 2rem;
            font-weight: 700;
            letter-spacing: 1px;
        }
        .icon-container {
    position: absolute;
    right: 15px;
    top: 70%;
    transform: translateY(-50%);
    cursor: pointer;
    z-index: 10;
    display: flex;
    align-items: center;
}
    </style>
</head>
<body>
<div class="container">
    <div class="col-md-5 mx-auto">
        <div class="card login-card bg-white">
            <div class="card-header text-center bg-primary text-white py-4">
                <h1 class="brand mb-1">EXFAKTOUR</h1>
                <p class="mb-0">Temukan dunia sekitarmu</p>
            </div>
            <div class="card-body p-4">
                <h4 class="text-center mb-4">Login/Daftar</h4>
                
                <?php if ($error): ?>
                    <div class="alert alert-danger text-center"><?= $error ?></div>
                <?php endif; ?>

                <form method="POST">
                    <div class="mb-3">
                        <label class="form-label">Username</label>
                        <input type="text" name="username" class="form-control form-control-lg" placeholder="Masukkan username" required>
                    </div>
                    <div class="mb-3 position-relative">
                        <label class="form-label">Password</label>
                        <input type="password" name="password" class="form-control form-control-lg" placeholder="Masukkan password" required>
                     
                    <div class="icon-container">
                        <i data-lucide="eye" id="eyeOpen" class="text-secondary"></i>
                        <i data-lucide="eye-off" id="eyeClose" class="text-secondary d-none"></i>
                    </div>
                 
                    </div>
                    <button type="submit" class="btn btn-primary w-100 btn-lg">Masuk</button>
                </form>

                
            </div>
            <div class="card-footer text-center text-muted py-2">
                &copy; <?= date('Y') ?> EXFAKTOUR. Semua Hak Dilindungi.
            </div>

        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    lucide.createIcons();

    const passwordInput = document.querySelector('input[name="password"]');
    const eyeOpen = document.getElementById('eyeOpen');
    const eyeClose = document.getElementById('eyeClose');

    eyeOpen.addEventListener('click', () => {
        passwordInput.type = 'text';
        eyeOpen.classList.add('d-none');
        eyeClose.classList.remove('d-none');
    });

    eyeClose.addEventListener('click', () => {
        passwordInput.type = 'password';
        eyeClose.classList.add('d-none');
        eyeOpen.classList.remove('d-none');
    });
});
</script>
</body>
</html>

</body>
</html>
