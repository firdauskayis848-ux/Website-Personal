<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit;
}
require_once "../config/database.php";

$id = $_GET['id'] ?? '';
$status = $_GET['status'] ?? '';

if ($id && $status) {
    $stmt = $pdo->prepare("UPDATE booking SET status=? WHERE id_booking=?");
    $stmt->execute([$status, $id]);
}

header("Location: booking.php");
exit;
?>
