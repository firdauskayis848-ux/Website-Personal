<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit;
}

require_once "../config/database.php";

// Ambil semua data destinasi
$stmt = $pdo->query("SELECT * FROM destinasi");
$destinasi = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Cari kolom ID
$id_column = null;
if (!empty($destinasi)) {
    $candidates = ['id', 'id_destinasi', 'id_destination', 'id_dest', 'idDestinasi'];
    foreach ($candidates as $c) {
        if (array_key_exists($c, $destinasi[0])) {
            $id_column = $c;
            break;
        }
    }

    if (!$id_column) {
        $keys = array_keys($destinasi[0]);
        $id_column = $keys[0];
    }

    // Urutkan descending berdasarkan ID
    usort($destinasi, function ($a, $b) use ($id_column) {
        $av = $a[$id_column] ?? null;
        $bv = $b[$id_column] ?? null;
        if (is_numeric($av) && is_numeric($bv)) {
            return $bv <=> $av;
        }
        return strcmp((string)$bv, (string)$av);
    });
}

// Tentukan kolom foto
$foto_column = null;
if (!empty($destinasi)) {
    $sample = $destinasi[0];
    foreach (['foto', 'gambar', 'image', 'photo'] as $f) {
        if (array_key_exists($f, $sample)) {
            $foto_column = $f;
            break;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <title>Kelola Destinasi</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="bg-light">
<div class="container mt-4">
    <h2 class="mb-4">Daftar Destinasi Wisata</h2>
    <a href="destinasi_form.php" class="btn btn-primary mb-3">+ Tambah Destinasi</a>

    <div class="card">
        <div class="card-body">
            <table class="table table-bordered table-striped align-middle">
                <thead class="table-dark">
                    <tr>
                        <th>#</th>
                        <th>Nama</th>
                        <th>Lokasi</th>
                        <th>Tiket</th>
                        <th>Jam Buka</th>
                        <th>Foto</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                <?php if ($destinasi): ?>
                    <?php $no = 1; foreach ($destinasi as $row): ?>
                        <tr>
                            <td><?= $no++ ?></td>
                            <td><?= htmlspecialchars($row['nama'] ?? '—') ?></td>
                            <td><?= htmlspecialchars($row['lokasi'] ?? '—') ?></td>
                            <td><?= htmlspecialchars($row['tiket'] ?? '—') ?></td>
                            <td><?= htmlspecialchars($row['jam_buka'] ?? '—') ?></td>
                            <td>
                                <?php
                                // Menampilkan foto dari folder uploads (di luar admin)
                                if ($foto_column && !empty($row[$foto_column])) {
                                    $path = "../uploads/" . $row[$foto_column];
                                    if (file_exists($path)) {
                                        echo '<img src="' . htmlspecialchars($path) . '" width="100" class="rounded shadow">';
                                    } else {
                                        echo '<span class="text-danger">File tidak ditemukan</span>';
                                    }
                                } else {
                                    echo '<span class="text-muted">Tidak ada foto</span>';
                                }
                                ?>
                            </td>
                            <td>
                                <?php
                                $id_val = $row[$id_column] ?? null;
                                if ($id_val !== null) {
                                    $id_enc = urlencode($id_val);
                                    echo '<a href="destinasi_form.php?id=' . $id_enc . '" class="btn btn-sm btn-warning me-1">Edit</a>';
                                    echo '<a href="destinasi_hapus.php?id=' . $id_enc . '" class="btn btn-sm btn-danger" onclick="return confirm(\'Yakin ingin menghapus destinasi ini?\')">Hapus</a>';
                                } else {
                                    echo '<span class="text-muted">ID tidak ditemukan</span>';
                                }
                                ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="7" class="text-center text-muted">Belum ada data destinasi</td>
                    </tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <a href="index.php" class="btn btn-secondary mt-3">Kembali</a>
</div>
<div class="card-footer text-center text-muted py-2">
                &copy; <?= date('Y') ?> EXFAKTOUR. Semua Hak Dilindungi.
            </div>
</body>
</html>
