<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit;
}

require_once "../config/database.php";

$id = $_GET['id'] ?? '';
$nama_hotel = $lokasi = $deskripsi = $whatsapp = "";
$harga_per_malam = $rating = 0;
$foto = "";
$latitude = $longitude = "";

if ($id) {
    $stmt = $pdo->prepare("SELECT * FROM hotel WHERE id_hotel=?");
    $stmt->execute([$id]);
    $data = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($data) {
        $nama_hotel = $data['nama_hotel'];
        $lokasi = $data['lokasi'];
        $deskripsi = $data['deskripsi'];
        $whatsapp = $data['whatsapp'];
        $harga_per_malam = $data['harga_per_malam'];
        $rating = $data['rating'];
        $foto = $data['foto'];
        $latitude = $data['latitude'];
        $longitude = $data['longitude'];
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nama_hotel = $_POST['nama_hotel'];
    $lokasi = $_POST['lokasi'];
    $deskripsi = $_POST['deskripsi'];
    $whatsapp = $_POST['whatsapp'];
    $harga_per_malam = $_POST['harga_per_malam'];
    $rating = $_POST['rating'];
    $latitude = $_POST['latitude'];
    $longitude = $_POST['longitude'];

    // Upload foto
    if (!empty($_FILES['foto']['name'])) {
        $fileName = time() . "_" . $_FILES['foto']['name'];
        move_uploaded_file($_FILES['foto']['tmp_name'], "../uploads/" . $fileName);
    } else {
        $fileName = $foto;
    }

    if ($id) {
        $stmt = $pdo->prepare("UPDATE hotel 
            SET nama_hotel=?, lokasi=?, deskripsi=?, whatsapp=?, harga_per_malam=?, rating=?, foto=?, latitude=?, longitude=? 
            WHERE id_hotel=?");
        $stmt->execute([$nama_hotel, $lokasi, $deskripsi, $whatsapp, $harga_per_malam, $rating, $fileName, $latitude, $longitude, $id]);
    } else {
        $stmt = $pdo->prepare("INSERT INTO hotel (nama_hotel, lokasi, deskripsi, whatsapp, harga_per_malam, rating, foto, latitude, longitude) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([$nama_hotel, $lokasi, $deskripsi, $whatsapp, $harga_per_malam, $rating, $fileName, $latitude, $longitude]);
    }

    header("Location: hotel.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title><?= $id ? 'Edit' : 'Tambah' ?> Hotel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container mt-4">
    <h2><?= $id ? 'Edit' : 'Tambah' ?> Hotel</h2>
    <form method="POST" enctype="multipart/form-data">
        <div class="mb-3">
            <label>Nama Hotel</label>
            <input type="text" name="nama_hotel" class="form-control" value="<?= htmlspecialchars($nama_hotel) ?>" required>
        </div>
        <div class="mb-3">
            <label>Lokasi</label>
            <input type="text" name="lokasi" class="form-control" value="<?= htmlspecialchars($lokasi) ?>" required>
        </div>
        <div class="mb-3">
            <label>Deskripsi</label>
            <textarea name="deskripsi" class="form-control" rows="4" required><?= htmlspecialchars($deskripsi) ?></textarea>
        </div>
        <div class="mb-3">
            <label>WhatsApp (nomor / link)</label>
            <input type="text" name="whatsapp" class="form-control" value="<?= htmlspecialchars($whatsapp) ?>" placeholder="Contoh: 08123456789 atau https://wa.me/628123456789">
        </div>
        <div class="mb-3">
            <label>Harga per Malam</label>
            <input type="number" name="harga_per_malam" class="form-control" value="<?= htmlspecialchars($harga_per_malam) ?>" required>
        </div>
        <div class="mb-3">
            <label>Rating (0-5)</label>
            <input type="number" step="0.1" min="0" max="5" name="rating" class="form-control" value="<?= htmlspecialchars($rating) ?>" required>
        </div>
        <div class="mb-3">
            <label>Latitude</label>
            <input type="text" name="latitude" class="form-control" value="<?= htmlspecialchars($latitude) ?>" placeholder="Contoh: -6.175110" required>
        </div>
        <div class="mb-3">
            <label>Longitude</label>
            <input type="text" name="longitude" class="form-control" value="<?= htmlspecialchars($longitude) ?>" placeholder="Contoh: 106.865036" required>
        </div>
        <div class="mb-3">
            <label>Foto Hotel</label>
            <input type="file" name="foto" class="form-control">
            <?php if ($foto): ?>
                <img src="../uploads/<?= htmlspecialchars($foto) ?>" width="120" class="mt-2 rounded shadow">
            <?php endif; ?>
        </div>
        <button class="btn btn-success"><?= $id ? 'Update' : 'Simpan' ?></button>
        <a href="hotel.php" class="btn btn-secondary">Kembali</a>
    </form>
</div>

<div class="card-footer text-center text-muted py-2 mt-4">
    &copy; <?= date('Y') ?> EXFAKTOUR. Semua Hak Dilindungi.
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
