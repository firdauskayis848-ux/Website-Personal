<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit;
}
require_once "../config/database.php";

// Ambil data artikel
$stmt = $pdo->query("SELECT * FROM artikel ORDER BY id_artikel DESC");
$artikel = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Kelola Artikel - Pariwita</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container mt-4">
  <h2><i class="bi bi-newspaper"></i> Kelola Artikel / Berita Wisata</h2>
  <a href="artikel_form.php" class="btn btn-primary mb-3"><i class="bi bi-plus-circle"></i> Tambah Artikel</a>
  <table class="table table-bordered table-striped">
    <thead class="table-dark">
      <tr>
        <th>No</th>
        <th>Judul</th>
        <th>Tanggal</th>
        <th>gambar</th>
        <th>Aksi</th>
      </tr>
    </thead>
    <tbody>
      <?php $no=1; foreach ($artikel as $row): ?>
      <tr>
        <td><?= $no++ ?></td>
        <td><?= htmlspecialchars($row['judul']) ?></td>
        <td><?= htmlspecialchars($row['tanggal']) ?></td>
        <td>
          <?php if (!empty($row['gambar']) && file_exists("../admin/uploads/".$row['gambar'])): ?>
            <img src="../admin/uploads/<?= htmlspecialchars($row['gambar']) ?>" width="100">
          <?php else: ?>
            <span class="text-muted">Tidak ada gambar</span>
          <?php endif; ?>
        </td>
        
        <td>
          <a href="artikel_form.php?id=<?= $row['id_artikel'] ?>" class="btn btn-warning btn-sm"><i class="bi bi-pencil"></i></a>
          <a href="artikel_hapus.php?id=<?= $row['id_artikel'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Yakin hapus artikel ini?')"><i class="bi bi-trash"></i></a>
        </td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
  <a href="index.php" class="btn btn-secondary"><i class="bi bi-arrow-left"></i> Kembali</a>
</div>
</body>
</html>
