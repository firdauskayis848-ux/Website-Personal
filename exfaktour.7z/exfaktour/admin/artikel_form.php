<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit;
}
require_once "../config/database.php";

$id = $_GET['id'] ?? '';
$judul = $isi = $tanggal = $gambar = '';

if ($id) {
    $stmt = $pdo->prepare("SELECT * FROM artikel WHERE id_artikel=?");
    $stmt->execute([$id]);
    $data = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($data) {
        $judul = $data['judul'];
        $isi = $data['isi'];
        $tanggal = $data['tanggal'];
        $gambar = $data['gambar'];
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $judul = $_POST['judul'];
    $isi = $_POST['isi'];
    $tanggal = $_POST['tanggal'];

    // Upload gambar
    if ($_FILES['gambar']['name']) {
        $fileName = time() . "_" . $_FILES['gambar']['name'];
        move_uploaded_file($_FILES['gambar']['tmp_name'], "../uploads/" . $fileName);
    } else {
        $fileName = $gambar;
    }

    if ($id) {
        $stmt = $pdo->prepare("UPDATE artikel SET judul=?, isi=?, tanggal=?, gambar=? WHERE id_artikel=?");
        $stmt->execute([$judul, $isi, $tanggal, $fileName, $id]);
    } else {
        $stmt = $pdo->prepare("INSERT INTO artikel (judul, isi, tanggal, gambar) VALUES (?,?,?,?)");
        $stmt->execute([$judul, $isi, $tanggal, $fileName]);
    }
    header("Location: artikel.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title><?= $id ? 'Edit' : 'Tambah' ?> Artikel</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container mt-4">
  <h2><?= $id ? 'Edit' : 'Tambah' ?> Artikel / Berita Wisata</h2>
  <form method="POST" enctype="multipart/form-data">
    <div class="mb-3">
      <label>Judul Artikel</label>
      <input type="text" name="judul" class="form-control" value="<?= htmlspecialchars($judul) ?>" required>
    </div>
    <div class="mb-3">
      <label>Isi Artikel</label>
      <textarea name="isi" rows="6" class="form-control" required><?= htmlspecialchars($isi) ?></textarea>
    </div>
    <div class="mb-3">
      <label>Tanggal</label>
      <input type="date" name="tanggal" class="form-control" value="<?= htmlspecialchars($tanggal) ?>" required>
    </div>
    
    <div class="mb-3">
      <label>gambar</label>
      <input type="file" name="gambar" class="form-control">
      <?php if ($gambar): ?>
        <img src="..admin/uploads/<?= $gambar ?>" width="120" class="mt-2">
      <?php endif; ?>
    </div>
    <button class="btn btn-success"><?= $id ? 'Update' : 'Simpan' ?></button>
    <a href="artikel.php" class="btn btn-secondary">Kembali</a>
  </form>
</div>
</body>
</html>
