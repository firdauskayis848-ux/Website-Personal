<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit;
}

require_once "../config/database.php";

// Ambil semua data hotel
$stmt = $pdo->query("SELECT * FROM hotel");
$hotels = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Cari kolom ID
$id_column = null;
if (!empty($hotels)) {
    $candidates = ['id', 'id_hotel'];
    foreach ($candidates as $c) {
        if (array_key_exists($c, $hotels[0])) {
            $id_column = $c;
            break;
        }
    }

    if (!$id_column) {
        $keys = array_keys($hotels[0]);
        $id_column = $keys[0];
    }

    // Urutkan descending berdasarkan ID
    usort($hotels, function ($a, $b) use ($id_column) {
        $av = $a[$id_column] ?? null;
        $bv = $b[$id_column] ?? null;
        if (is_numeric($av) && is_numeric($bv)) {
            return $bv <=> $av;
        }
        return strcmp((string)$bv, (string)$av);
    });
}

// Tentukan kolom foto
$foto_column = null;
if (!empty($hotels)) {
    $sample = $hotels[0];
    foreach (['foto', 'gambar', 'image', 'photo'] as $f) {
        if (array_key_exists($f, $sample)) {
            $foto_column = $f;
            break;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <title>Kelola Hotel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="bg-light">
<div class="container mt-4">
    <h2 class="mb-4">Daftar Hotel</h2>
    <a href="hotel_form.php" class="btn btn-primary mb-3">+ Tambah Hotel</a>

    <div class="card">
        <div class="card-body">
            <table class="table table-bordered table-striped align-middle">
                <thead class="table-dark">
                    <tr>
                        <th>#</th>
                        <th>Nama Hotel</th>
                        <th>Lokasi</th>
                        <th>Harga / Malam</th>
                        <th>Rating</th>
                        <th>Foto</th>
                        <th>WhatsApp</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                <?php if ($hotels): ?>
                    <?php $no = 1; foreach ($hotels as $row): ?>
                        <tr>
                            <td><?= $no++ ?></td>
                            <td><?= htmlspecialchars($row['nama_hotel'] ?? '—') ?></td>
                            <td><?= htmlspecialchars($row['lokasi'] ?? '—') ?></td>
                            <td>Rp <?= number_format($row['harga_per_malam'] ?? 0, 0, ',', '.') ?></td>
                            <td><?= number_format($row['rating'] ?? 0, 1) ?></td>
                            <td>
                                <?php
                                if ($foto_column && !empty($row[$foto_column])) {
                                    $path = "../uploads/" . $row[$foto_column];
                                    if (file_exists($path)) {
                                        echo '<img src="' . htmlspecialchars($path) . '" width="100" class="rounded shadow">';
                                    } else {
                                        echo '<span class="text-danger">File tidak ditemukan</span>';
                                    }
                                } else {
                                    echo '<span class="text-muted">Tidak ada foto</span>';
                                }
                                ?>
                            </td>
                            <td>
                                <?php
                                if (!empty($row['whatsapp'])) {
                                    $waNumber = preg_replace('/[^0-9]/', '', $row['whatsapp']);
                                    $waLink = (strpos($waNumber, '62') === 0) ? "https://wa.me/$waNumber" : "https://wa.me/62$waNumber";
                                    echo '<a href="'.$waLink.'" target="_blank" class="btn btn-success btn-sm">WA</a>';
                                } else {
                                    echo '<span class="text-muted">—</span>';
                                }
                                ?>
                            </td>
                            <td>
                                <?php
                                $id_val = $row[$id_column] ?? null;
                                if ($id_val !== null) {
                                    $id_enc = urlencode($id_val);
                                    echo '<a href="hotel_form.php?id=' . $id_enc . '" class="btn btn-sm btn-warning me-1">Edit</a>';
                                    echo '<a href="hotel_hapus.php?id=' . $id_enc . '" class="btn btn-sm btn-danger" onclick="return confirm(\'Yakin ingin menghapus hotel ini?\')">Hapus</a>';
                                } else {
                                    echo '<span class="text-muted">ID tidak ditemukan</span>';
                                }
                                ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="8" class="text-center text-muted">Belum ada data hotel</td>
                    </tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <a href="index.php" class="btn btn-secondary mt-3">Kembali</a>
</div>

<div class="card-footer text-center text-muted py-2">
    &copy; <?= date('Y') ?> EXFAKTOUR. Semua Hak Dilindungi.
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
