<?php
session_start();
require_once "../config/database.php";

if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit;
}

// =============================
// HAPUS REVIEW
// =============================
if (isset($_GET['hapus'])) {
    $id = $_GET['hapus'];
    $stmt = $pdo->prepare("DELETE FROM review WHERE id_review=?");
    $stmt->execute([$id]);

    header("Location: review.php");
    exit;
}

// =============================
// AMBIL SEMUA REVIEW
// =============================
$reviews = $pdo->query("SELECT * FROM review ORDER BY tanggal DESC")->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Moderasi Review - Admin Pariwita</title>
</head>
<body>
    <h1>🛠 Moderasi Review</h1>
    <a href="index.php">⬅ Kembali ke Dashboard</a>
    <hr>

    <table border="1" cellpadding="8">
        <tr>
            <th>No</th>
            <th>Nama</th>
            <th>Kategori</th>
            <th>ID Item</th>
            <th>Rating</th>
            <th>Komentar</th>
            <th>Tanggal</th>
            <th>Aksi</th>
        </tr>
        <?php $no=1; foreach ($reviews as $r): ?>
        <tr>
            <td><?= $no++ ?></td>
            <td><?= htmlspecialchars($r['nama']) ?></td>
            <td><?= ucfirst($r['kategori']) ?></td>
            <td><?= $r['id_item'] ?></td>
            <td>⭐ <?= $r['rating'] ?></td>
            <td><?= nl2br(htmlspecialchars($r['komentar'])) ?></td>
            <td><?= $r['tanggal'] ?></td>
            <td>
                <a href="review.php?hapus=<?= $r['id_review'] ?>" onclick="return confirm('Yakin hapus review ini?')">🗑 Hapus</a>
            </td>
        </tr>
        <?php endforeach; ?>
    </table>

    <?php if (count($reviews) === 0): ?>
        <p><i>Belum ada review dari pengguna.</i></p>
    <?php endif; ?>
</body>
</html>
