<?php
require_once "../config/database.php";
$artikel = $pdo->query("SELECT * FROM artikel ORDER BY tanggal DESC")->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Artikel Wisata - Pariwita</title>
</head>
<body>
    <h1>📰 Artikel & Berita Wisata</h1>
    <a href="index.php">⬅ Kembali ke Home</a>
    <hr>

    <?php foreach ($artikel as $a): ?>
        <div style="margin-bottom:20px; border-bottom:1px solid #ccc; padding:10px;">
            <h2><?= $a['judul'] ?></h2>
            <small>📅 <?= date("d M Y", strtotime($a['tanggal'])) ?></small><br>
            <?php if ($a['gambar']): ?>
                <img src="../assets/img/<?= $a['gambar'] ?>" width="250"><br>
            <?php endif; ?>
            <p><?= substr($a['isi'], 0, 150) ?>...</p>
            <a href="detail_artikel.php?id=<?= $a['id_artikel'] ?>">Baca selengkapnya ➡</a>
        </div>
    <?php endforeach; ?>
</body>
</html>
