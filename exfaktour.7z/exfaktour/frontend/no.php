<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menu Layanan WhatsApp</title>
    
    <script src="https://cdn.tailwindcss.com"></script>
    
    <script src="https://unpkg.com/lucide@latest"></script>

    <style>
        /* CSS tambahan untuk memastikan tampilan rapi */
        body {
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            background-color: #f9fafb; /* bg-gray-50 */
            font-family: sans-serif;
        }
        .icon-container {
            display: flex;
            flex-direction: column;
            align-items: center;
            text-align: center;
            color: #4b5563; /* text-gray-600 */
            text-decoration: none;
            transition: transform 0.2s;
        }
        .icon-container:hover {
            transform: scale(1.1);
        }
        .icon-background {
            width: 64px; /* w-16 */
            height: 64px; /* h-16 */
            background-color: #e5e7eb; /* bg-gray-200 */
            border-radius: 9999px; /* rounded-full */
            display: flex;
            justify-content: center;
            align-items: center;
            margin-bottom: 8px; /* mb-2 */
        }
        .icon-text {
            font-size: 0.875rem; /* text-sm */
            font-weight: 500; /* font-medium */
        }
    </style>
</head>
<body>

    <div class="flex flex-wrap justify-center gap-6 p-4">

        <a href="https://wa.me/6281234567890?text=Halo,%20saya%20tertarik%20untuk%20menyewa%20mobil%20(ExCar)." target="_blank" class="icon-container">
            <div class="icon-background">
                <i data-lucide="car" class="w-8 h-8"></i>
            </div>
            <span class="icon-text">ExCar</span>
        </a>

        <a href="https://wa.me/6281234567890?text=Halo,%20saya%20tertarik%20untuk%20menyewa%20motor%20(ExMotor)." target="_blank" class="icon-container">
            <div class="icon-background">
                <i data-lucide="bike" class="w-8 h-8"></i>
            </div>
            <span class="icon-text">ExMotor</span>
        </a>

        <a href="https://wa.me/6281234567890?text=Halo,%20saya%20tertarik%20untuk%20menyewa%20kapal%20(ExBoat)." target="_blank" class="icon-container">
            <div class="icon-background">
                <i data-lucide="ship" class="w-8 h-8"></i>
            </div>
            <span class="icon-text">ExBoat</span>
        </a>
        
        <a href="https://wa.me/6281234567890?text=Halo,%20saya%20ingin%20bertanya%20tentang%20promo%20yang%20tersedia." target="_blank" class="icon-container">
            <div class="icon-background">
                <i data-lucide="ticket-percent" class="w-8 h-8"></i>
            </div>
            <span class="icon-text">Promo</span>
        </a>
        
        <a href="https://wa.me/6281234567890?text=Halo,%20saya%20memiliki%20pertanyaan%20terkait%20fitur%20Scan." target="_blank" class="icon-container">
            <div class="icon-background">
                <i data-lucide="scan-line" class="w-8 h-8"></i>
            </div>
            <span class="icon-text">Scan</span>
        </a>

    </div>

    <script>
      lucide.createIcons();
    </script>

</body>
</html>