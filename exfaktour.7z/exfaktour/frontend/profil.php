<?php
session_start();
require_once "../config/database.php";

// Cek apakah user sudah login
if (!isset($_SESSION['user_id'])) {
    header("Location: login_user.php");
    exit;
}

$user_id = $_SESSION['user_id'];

// Ambil data user dari database
$stmt = $pdo->prepare("SELECT * FROM users WHERE id_user = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profil Saya | EXFAKTOUR</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
</head>
<body class="bg-gradient-to-b from-blue-100 via-indigo-100 to-white min-h-screen flex flex-col">

    <!-- Navbar -->
    <nav class="bg-white shadow-md py-4 px-6 flex justify-between items-center fixed top-0 w-full z-10">
        <div class="flex items-center gap-2">
            <i data-lucide="map" class="text-blue-600 w-6 h-6"></i>
            <span class="text-xl font-bold text-blue-700">EXFAKTOUR</span>
        </div>
        <a href="index.php" class="flex items-center gap-1 text-blue-600 hover:text-blue-800">
            <i data-lucide="home"></i> <span>Beranda</span>
        </a>
    </nav>
    <main class="flex-grow flex items-center justify-center p-6 mt-20">
<body class="bg-gradient-to-br from-blue-50 to-indigo-100 min-h-screen flex items-center justify-center p-6">

    <div class="bg-white shadow-xl rounded-2xl p-8 max-w-md w-full text-center">
        <!-- Foto Profil -->
        <div class="relative inline-block mb-5">
            <div class="w-28 h-28 bg-blue-100 rounded-full flex items-center justify-center mx-auto border-4 border-blue-500 overflow-hidden">
                <?php if (!empty($user['foto'])): ?>
                    <img src="../uploads/<?= htmlspecialchars($user['foto']) ?>" alt="Foto Profil" class="object-cover w-full h-full">
                <?php else: ?>
                    <i data-lucide="user" class="w-12 h-12 text-blue-600"></i>
                <?php endif; ?>
            </div>

            <!-- Tombol Unggah Foto -->
            <form action="upload.php" method="POST" enctype="multipart/form-data" class="mt-4 flex flex-col items-center">
                <label for="foto" class="cursor-pointer bg-blue-50 hover:bg-blue-100 text-blue-700 py-2 px-4 rounded-lg text-sm font-medium flex items-center gap-2 transition">
                    <i data-lucide="upload" class="w-4 h-4"></i>
                    Pilih Foto
                </label>
                <input type="file" name="foto" id="foto" accept="image/*" class="hidden" onchange="this.form.submit()">
                
                    
                </button>
            </form>
        </div>

        <!-- Data User -->
        <h2 class="text-2xl font-bold text-gray-800 mb-2"><?= htmlspecialchars($user['nama']) ?></h2>
        <p class="text-gray-500 text-sm mb-4"><?= htmlspecialchars($user['email']) ?></p>

        <div class="border-t border-gray-200 my-5"></div>

        <div class="text-left space-y-3">
            <div class="flex items-center gap-3">
                <i data-lucide="user-circle" class="text-blue-600 w-5 h-5"></i>
                <span class="font-medium text-gray-700"><?= htmlspecialchars($user['nama']) ?></span>
            </div>
            <div class="flex items-center gap-3">
                <i data-lucide="mail" class="text-blue-600 w-5 h-5"></i>
                <span class="text-gray-700"><?= htmlspecialchars($user['email']) ?></span>
            </div>
            <div class="flex items-center gap-3">
                <i data-lucide="calendar" class="text-blue-600 w-5 h-5"></i>
                <span class="text-gray-700">Bergabung sejak: <?= date('d M Y', strtotime($user['created_at'] ?? date('Y-m-d'))) ?></span>
            </div>
        </div>

        <!-- Tombol Aksi -->
        <div class="mt-8 flex flex-col gap-3">
            <a href="edit_profil.php" class="bg-blue-600 hover:bg-blue-700 text-white py-2 rounded-lg font-semibold flex items-center justify-center gap-2 transition">
                <i data-lucide="edit"></i> Edit Profil
            </a>
            <a href="login_user.php" class="bg-red-500 hover:bg-red-600 text-white py-2 rounded-lg font-semibold flex items-center justify-center gap-2 transition">
                <i data-lucide="log-out"></i> Logout
            </a>
        </div>
    </div>

    <script>
        document.addEventListener("DOMContentLoaded", function() {
            lucide.createIcons();
        });
    </script>
</body>
</html>
