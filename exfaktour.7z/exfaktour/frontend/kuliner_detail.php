<?php
require_once "../config/database.php";

// Ambil ID dari URL
$id = isset($_GET['id']) ? (int) $_GET['id'] : 0;

// Ambil data kuliner berdasarkan ID
$stmt = $pdo->prepare("SELECT * FROM kuliner WHERE id_kuliner = ?");
$stmt->execute([$id]);
$k = $stmt->fetch(PDO::FETCH_ASSOC);

// Jika data tidak ditemukan
if (!$k) {
  die("<div class='container text-center mt-5'>
        <h4 class='text-danger'>❌ Data kuliner tidak ditemukan.</h4>
        <a href='kuliner.php' class='btn btn-secondary mt-3'>Kembali</a>
      </div>");
}

// Fungsi format rupiah
function formatRupiah($angka) {
  return "Rp" . number_format($angka, 0, ',', '.');
}

// Pisahkan deskripsi menjadi daftar menu|harga
$menuList = [];
$lines = explode("\n", $k['deskripsi']);
foreach ($lines as $line) {
  $parts = explode("|", trim($line));
  if (count($parts) == 2) {
    $menuList[] = [
      'nama' => trim($parts[0]),
      'harga' => trim($parts[1])
    ];
  }
}

// Siapkan link WhatsApp (jika nomor tersedia)
$waLink = "";
if (!empty($k['whatsapp'])) {
  $pesan = urlencode("Halo! Saya ingin memesan atau menanyakan tentang kuliner *{$k['nama']}*.");
  $waLink = "https://wa.me/{$k['whatsapp']}?text={$pesan}";
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Detail Kuliner - <?= htmlspecialchars($k['nama']) ?></title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
  <style>
    body { background-color: #f8f9fa; }
    .card-img-top { border-bottom: 3px solid #198754; }
    table th { background-color: #198754; color: white; }
  </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-success shadow">
  <div class="container">
    <a class="navbar-brand fw-bold" href="index.php">EXFAKTOUR</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ms-auto">
        <li class="nav-item"><a href="index.php" class="nav-link text-white">BERANDA</a></li>
       
      </ul>
    </div>
  </div>
</nav>

<!-- Konten -->
<div class="container py-5">
  <div class="row justify-content-center">
    <div class="col-md-8">
      <div class="card shadow-lg border-0 rounded-4 overflow-hidden">
        <?php if (!empty($k['gambar'])): ?>
          <img src="../uploads/<?= htmlspecialchars($k['gambar']) ?>" 
               class="card-img-top" 
               alt="<?= htmlspecialchars($k['nama']) ?>" 
               style="height:400px; object-fit:cover;">
        <?php else: ?>
          <img src="https://via.placeholder.com/800x400?text=No+Image" 
               class="card-img-top" alt="No Image">
        <?php endif; ?>

        <div class="card-body">
          <h2 class="card-title text-success"><?= htmlspecialchars($k['nama']) ?></h2>
          <p class="text-muted mb-2"><i class="bi bi-geo-alt"></i> <?= htmlspecialchars($k['lokasi']) ?></p>
          <hr>

          <h5 class="fw-bold">Menu & Harga:</h5>
          <?php if (!empty($menuList)): ?>
            <p class="text-muted fst-italic mb-2">
              Berikut daftar menu dan harga yang tersedia di tempat ini:
            </p>
            <div class="table-responsive">
              <table class="table table-bordered align-middle">
                <thead>
                  <tr>
                    <th>Nama Menu</th>
                    <th>Harga</th>
                  </tr>
                </thead>
                <tbody>
                  <?php foreach ($menuList as $menu): ?>
                    <tr>
                      <td><?= htmlspecialchars($menu['nama']) ?></td>
                      <td><?= formatRupiah($menu['harga']) ?></td>
                    </tr>
                  <?php endforeach; ?>
                </tbody>
              </table>
            </div>
          <?php else: ?>
            <p><?= nl2br(htmlspecialchars($k['deskripsi'])) ?></p>
          <?php endif; ?>

          <hr>
          <p><b>Jam Buka:</b> <?= htmlspecialchars($k['jam_buka']) ?></p>
          <?php if (!empty($k['latitude']) && !empty($k['longitude'])): ?>
            <p><b>Koordinat:</b> <?= htmlspecialchars($k['latitude']) ?> , <?= htmlspecialchars($k['longitude']) ?></p>
          <?php endif; ?>
        </div>

        <div class="card-footer bg-white border-0 d-flex justify-content-between flex-wrap gap-2">
          <a href="kuliner.php" class="btn btn-outline-secondary">
            ← Kembali
          </a>
          <?php if (!empty($k['latitude']) && !empty($k['longitude'])): ?>
            <a href="https://www.google.com/maps?q=<?= $k['latitude'] ?>,<?= $k['longitude'] ?>" 
               target="_blank" class="btn btn-success">
              📍 Lihat di Google Maps
            </a>
          <?php endif; ?>
          <?php if (!empty($waLink)): ?>
            <a href="<?= $waLink ?>" target="_blank" class="btn btn-outline-success">
              💬 Pesan via WhatsApp
            </a>
          <?php endif; ?>
        </div>
      </div>
    </div>
  </div>
</div>

<div class="card-footer text-center text-muted py-2">
                &copy; <?= date('Y') ?> EXFAKTOUR. Semua Hak Dilindungi.
            </div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
