<?php
require_once "../config/database.php";

$id = $_GET['id'];
$stmt = $pdo->prepare("SELECT * FROM artikel WHERE id_artikel=?");
$stmt->execute([$id]);
$a = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$a) {
    die("Artikel tidak ditemukan!");
}
?>

<!DOCTYPE html>
<html>
<head>
    <title><?= $a['judul'] ?> - Pariwita</title>
</head>
<body>
    <a href="artikel.php">⬅ Kembali ke Artikel</a>
    <h1><?= $a['judul'] ?></h1>
    <small>📅 <?= date("d M Y", strtotime($a['tanggal'])) ?></small><br>
    <?php if ($a['gambar']): ?>
        <img src="../assets/img/<?= $a['gambar'] ?>" width="350"><br>
    <?php endif; ?>
    <p><?= nl2br($a['isi']) ?></p>
</body>
<div class="card-footer text-center text-muted py-2">
                &copy; <?= date('Y') ?> EXFAKTOUR. Semua Hak Dilindungi.
            </div>
</html>
