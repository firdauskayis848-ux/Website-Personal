<?php
require_once "../config/database.php";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nama     = $_POST['nama'];
    $kategori = $_POST['kategori']; // destinasi / kuliner
    $id_item  = $_POST['id_item'];
    $rating   = $_POST['rating'];
    $komentar = $_POST['komentar'];

    $stmt = $pdo->prepare("INSERT INTO review (nama, kategori, id_item, rating, komentar) VALUES (?, ?, ?, ?, ?)");
    $stmt->execute([$nama, $kategori, $id_item, $rating, $komentar]);

    $pesan = "Review berhasil dikirim!";
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Tambah Review - Pariwita</title>
</head>
<body>
    <h1>📝 Tambah Review & Rating</h1>
    <a href="index.php">⬅ Kembali ke Home</a>
    <hr>

    <?php if (!empty($pesan)) echo "<p style='color:green;'>$pesan</p>"; ?>

    <form method="POST">
        <label>Nama Anda:</label><br>
        <input type="text" name="nama" required><br><br>

        <label>Kategori:</label><br>
        <select name="kategori" required>
            <option value="destinasi">Destinasi</option>
            <option value="kuliner">Kuliner</option>
        </select><br><br>

        <label>ID Item (Destinasi/Kuliner):</label><br>
        <input type="number" name="id_item" required><br><br>

        <label>Rating:</label><br>
        <select name="rating" required>
            <option value="5">⭐⭐⭐⭐⭐ (5)</option>
            <option value="4">⭐⭐⭐⭐ (4)</option>
            <option value="3">⭐⭐⭐ (3)</option>
            <option value="2">⭐⭐ (2)</option>
            <option value="1">⭐ (1)</option>
        </select><br><br>

        <label>Komentar:</label><br>
        <textarea name="komentar" rows="4" cols="40"></textarea><br><br>

        <button type="submit">Kirim Review</button>
    </form>
</body>
</html>
