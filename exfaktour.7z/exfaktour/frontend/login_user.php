<?php

session_start();
require_once "../config/database.php";

$error = "";

// Jika form dikirim
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email']);
    $password = $_POST['password'];

    $stmt = $pdo->prepare("SELECT * FROM users WHERE LOWER(email) = LOWER(?)");
    $stmt->execute([$email]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user_id'] = $user['id_user'];
        $_SESSION['nama_user'] = $user['nama'];
        header("Location: index.php");
        exit;
    } else {
        $error = "Email atau password salah!";
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EXFAKTOUR | Login User</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://unpkg.com/lucide@latest"></script>
    <style>
        body {
            background: linear-gradient(180deg, #f5f7ff, #e3e8ff);
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }
        .login-container {
            background: #fff;
            border-radius: 1rem;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.1);
            width: 400px;
            padding: 2rem 2.5rem;
            animation: fadeIn 0.6s ease-in-out;
        }
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(30px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .brand {
            text-align: center;
            font-size: 1.8rem;
            font-weight: 700;
            color: #0d6efd;
        }
        .subtext {
            text-align: center;
            color: #555;
            font-size: 0.9rem;
            margin-bottom: 1.2rem;
        }
        .toggle-eye {
            position: absolute;
            right: 15px;
            top: 50%;
            transform: translateY(-50%);
            cursor: pointer;
            color: #6c757d;
        }
        .btn-dark {
            background: #212529;
            border: none;
        }
        .btn-dark:hover {
            background: #111;
        } .icon-container {
            position: absolute;
            right: 15px;
            top: 70%;
            transform: translateY(-50%);
            cursor: pointer;
            display: flex;
            align-items: center;
            z-index: 10;
        }
        a {
            text-decoration: none;
        }
    </style>
</head>
<body>
<div class="login-container">
    <h2 class="brand">EXFAKTOUR</h2>
    <p class="subtext">Temukan dunia sekitarmu dengan EXFAKTOUR</p>

    <h5 class="text-center fw-bold mb-4">Login/Daftar</h5>

    <?php if ($error): ?>
        <div class="alert alert-danger text-center"><?= $error ?></div>
    <?php endif; ?>

    <form method="POST">
        <div class="mb-3">
            <label for="email" class="form-label">Email</label>
            <input type="text" id="email" name="email" class="form-control form-control-lg bg-light" placeholder="Masukkan email" required>
        </div>

        <div class="mb-3 position-relative">
            <label for="password" class="form-label">Password</label>
            <input type="password" id="password" name="password" class="form-control form-control-lg bg-light" placeholder="Masukkan password" required>
        <div class="icon-container">
             <i data-lucide="eye" id="eyeOpen" class="text-secondary"></i>
             <i data-lucide="eye-off" id="eyeClose" class="text-secondary d-none"></i>
        </div>
            
</div>
        <button type="submit" class="btn btn-dark w-100 py-2 fw-bold">Lanjutkan</button>
    </form>

    <div class="text-center mt-3">
        <small>atau</small><br>
        <small>Baru menggunakan EXFAKTOUR? <a href="register_user.php" class="text-primary fw-bold">Buat akun</a></small>
    </div>

    <div class="text-center mt-3">
        <a href="../admin/login.php" class="text-primary fw-bold ">Login sebagai Admin</a>
    </div>

    <div class="text-center text-muted small mt-3">
        &copy; <?= date('Y') ?> EXFAKTOUR. Semua Hak Dilindungi.
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    lucide.createIcons();

    const passwordInput = document.querySelector('input[name="password"]');
    const eyeOpen = document.getElementById('eyeOpen');
    const eyeClose = document.getElementById('eyeClose');

    eyeOpen.addEventListener('click', () => {
        passwordInput.type = 'text';
        eyeOpen.classList.add('d-none');
        eyeClose.classList.remove('d-none');
    });

    eyeClose.addEventListener('click', () => {
        passwordInput.type = 'password';
        eyeClose.classList.add('d-none');
        eyeOpen.classList.remove('d-none');
    });
});
</script>
</body>
</html>
