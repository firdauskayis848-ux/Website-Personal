<?php
session_start();
require_once "../config/database.php";

// Cek login
if (!isset($_SESSION['user_id'])) {
    header("Location: login_user.php");
    exit;
}

$user_id = $_SESSION['user_id'];

// Ambil data user
$stmt = $pdo->prepare("SELECT * FROM users WHERE id_user = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

// === Upload Foto Profil ===
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['foto'])) {
    $file = $_FILES['foto'];
    if ($file['error'] === 0) {
        $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        $allowed = ['jpg', 'jpeg', 'png', 'webp'];

        if (in_array($ext, $allowed)) {
            $filename = "user_" . $user_id . "_" . time() . "." . $ext;
            $path = "../uploads/users/" . $filename;

            // Buat folder jika belum ada
            if (!is_dir("../uploads/users")) {
                mkdir("../uploads/users", 0777, true);
            }

            // Hapus foto lama jika ada
            if (!empty($user['foto']) && file_exists("../uploads/users/" . $user['foto'])) {
                unlink("../uploads/users/" . $user['foto']);
            }

            // Pindahkan file
            move_uploaded_file($file['tmp_name'], $path);

            // Update database
            $update = $pdo->prepare("UPDATE users SET foto = ? WHERE id_user = ?");
            $update->execute([$filename, $user_id]);

            // Refresh halaman
            header("Location: profil_user.php");
            exit;
        } else {
            $error = "Format file tidak diizinkan (hanya JPG, PNG, WEBP)";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Profil Saya | EXFAKTOUR</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <script src="https://unpkg.com/lucide@latest"></script>
</head>
<body class="bg-gradient-to-br from-blue-50 to-indigo-100 min-h-screen flex flex-col">

  <!-- Header -->
  <header class="bg-blue-600 text-white p-4 shadow-md flex items-center justify-between">
    <h1 class="text-lg font-bold">Profil Saya</h1>
    <a href="index.php" class="text-sm bg-white/20 px-3 py-1 rounded-md hover:bg-white/30">🏠 Beranda</a>
  </header>

  <!-- Info Profil -->
  <section class="text-center mt-8 px-4">
    <form action="" method="POST" enctype="multipart/form-data" class="relative inline-block">
       <div class="w-28 h-28 bg-blue-100 rounded-full mx-auto flex items-center justify-center border-4 border-blue-500 overflow-hidden shadow-md relative">
      <div class="w-28 h-28 bg-blue-100 rounded-full mx-auto flex items-center justify-center border-4 border-blue-500 overflow-hidden shadow-md relative">
        <?php if (!empty($user['foto']) && file_exists("../uploads/users/" . $user['foto'])): ?>
          <img src="../uploads/users/<?= htmlspecialchars($user['foto']) ?>" alt="Foto Profil" class="w-full h-full object-cover">
        <?php else: ?>
          <i data-lucide="user" class="w-12 h-12 text-blue-600"></i>
        <?php endif; ?>
      </div>

      <!-- Tombol ganti foto -->
      <label for="foto" class="absolute bottom-0 right-1/3 bg-blue-600 hover:bg-blue-700 text-white rounded-full p-2 cursor-pointer shadow">
        <i data-lucide="camera" class="w-4 h-4"></i>
      </label>
      <input type="file" name="foto" id="foto" class="hidden" accept="image/*" onchange="this.form.submit()">
    </form>

    <h2 class="mt-4 text-2xl font-bold text-gray-800"><?= htmlspecialchars($user['nama']) ?></h2>
    <p class="text-gray-500 text-sm"><?= htmlspecialchars($user['email']) ?></p>
    <p class="text-gray-400 text-xs mt-1">Bergabung sejak <?= date('d M Y', strtotime($user['created_at'] ?? date('Y-m-d'))) ?></p>
  </section>

  <!-- Grid Menu -->
  <section class="mt-10 px-6">
    <div class="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">

      <a href="edit_profil.php" class="bg-white rounded-xl p-4 shadow hover:shadow-lg transition flex flex-col items-center">
        <i data-lucide="edit" class="w-8 h-8 text-blue-600 mb-2"></i>
        <span class="text-sm font-semibold text-gray-700">Edit Profil</span>
      </a>

      <a href="riwayat.php" class="bg-white rounded-xl p-4 shadow hover:shadow-lg transition flex flex-col items-center">
        <i data-lucide="clock" class="w-8 h-8 text-blue-600 mb-2"></i>
        <span class="text-sm font-semibold text-gray-700">Riwayat</span>
      </a>

      <a href="bantuan.php" class="bg-white rounded-xl p-4 shadow hover:shadow-lg transition flex flex-col items-center">
        <i data-lucide="help-circle" class="w-8 h-8 text-blue-600 mb-2"></i>
        <span class="text-sm font-semibold text-gray-700">Bantuan</span>
      </a>

      <a href="logout_user.php" class="bg-white rounded-xl p-4 shadow hover:shadow-lg transition flex flex-col items-center">
        <i data-lucide="log-out" class="w-8 h-8 text-red-600 mb-2"></i>
        <span class="text-sm font-semibold text-red-600">Logout</span>
      </a>

    </div>
  </section>

  <!-- Footer -->
  <footer class="mt-auto text-center text-gray-500 text-sm py-4">
    &copy; <?= date('Y') ?> EXFAKTOUR. Semua Hak Dilindungi.
  </footer>

  <script>
    document.addEventListener("DOMContentLoaded", function() {
      lucide.createIcons();
    });
  </script>

</body>
</html>
