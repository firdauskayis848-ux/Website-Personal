<?php
require_once "../config/database.php";

// ambil data tujuan (misalnya 1 destinasi)
$id = $_GET['id'] ?? 1;
$stmt = $pdo->prepare("SELECT * FROM destinasi WHERE id_destinasi=?");
$stmt->execute([$id]);
$tujuan = $stmt->fetch(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Rute ke <?= htmlspecialchars($tujuan['nama']) ?></title>
  <link rel="stylesheet" href="https://unpkg.com/leaflet/dist/leaflet.css"/>
  <script src="https://unpkg.com/leaflet/dist/leaflet.js"></script>
  <script src="https://unpkg.com/leaflet-routing-machine/dist/leaflet-routing-machine.js"></script>
  <link rel="stylesheet" href="https://unpkg.com/leaflet-routing-machine/dist/leaflet-routing-machine.css"/>
  <style>
    #map { height: 600px; width: 100%; }
  </style>
</head>
<body>
  <h3>Rute dari Lokasi Anda ke <?= htmlspecialchars($tujuan['nama']) ?></h3>
  <div id="map"></div>

  <script>
    var map = L.map('map').setView([<?= $tujuan['latitude'] ?>, <?= $tujuan['longitude'] ?>], 13);

    // Tambahkan tile peta
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '&copy; OpenStreetMap contributors'
    }).addTo(map);

    // Lokasi tujuan (dari database PHP)
    var tujuan = L.latLng(<?= $tujuan['latitude'] ?>, <?= $tujuan['longitude'] ?>);
    L.marker(tujuan).addTo(map).bindPopup("<?= htmlspecialchars($tujuan['nama']) ?>").openPopup();

    // Cari lokasi user
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(function(position) {
        var userLatLng = L.latLng(position.coords.latitude, position.coords.longitude);

        // Tambahkan marker user
        L.marker(userLatLng).addTo(map).bindPopup("Lokasi Anda").openPopup();

        // Buat rute otomatis
        L.Routing.control({
          waypoints: [ userLatLng, tujuan ],
          routeWhileDragging: true
        }).addTo(map);

      }, function(error) {
        alert("Gagal mendapatkan lokasi Anda!");
      });
    } else {
      alert("Browser tidak mendukung geolokasi");
    }
  </script>
</body>
</html>
