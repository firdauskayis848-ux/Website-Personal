<?php
require_once "config/database.php";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nama = $_POST['nama'];
    $email = $_POST['email'];
    $destinasi = $_POST['destinasi'];
    $jumlah_tiket = $_POST['jumlah_tiket'];
    $tanggal = $_POST['tanggal'];

    $stmt = $pdo->prepare("INSERT INTO booking (nama, email, destinasi, jumlah_tiket, tanggal) VALUES (?,?,?,?,?)");
    $stmt->execute([$nama, $email, $destinasi, $jumlah_tiket, $tanggal]);

    echo "<script>alert('Booking berhasil dikirim, silakan tunggu konfirmasi admin');window.location='index.php';</script>";
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Booking Tiket - Pariwita</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container mt-4">
  <h2>Form Booking Tiket / Paket Wisata</h2>
  <form method="POST">
    <div class="mb-3">
      <label>Nama Lengkap</label>
      <input type="text" name="nama" class="form-control" required>
    </div>
    <div class="mb-3">
      <label>Email</label>
      <input type="email" name="email" class="form-control" required>
    </div>
    <div class="mb-3">
      <label>Destinasi</label>
      <input type="text" name="destinasi" class="form-control" required>
    </div>
    <div class="mb-3">
      <label>Jumlah Tiket</label>
      <input type="number" name="jumlah_tiket" class="form-control" required>
    </div>
    <div class="mb-3">
      <label>Tanggal Kunjungan</label>
      <input type="date" name="tanggal" class="form-control" required>
    </div>
    <button class="btn btn-success">Kirim Booking</button>
  </form>
</div>
</body>
</html>
