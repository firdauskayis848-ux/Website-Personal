<?php
require_once "../config/database.php";
$kuliner = $pdo->query("SELECT * FROM kuliner")->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>EXFAKTOUR - Kuliner Lokal</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
</head>
<body class="bg-light">

  <!-- Navbar -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
    <div class="container">
      <a class="navbar-brand fw-bold" href="index.php">EXFAKTOUR</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav ms-auto">
          <li class="nav-item"><a class="nav-link active" href="index.php">BERANDA</a></li>
          
        </ul>
      </div>
    </div>
  </nav>

  <!-- Konten -->
  <div class="container mt-4">
    <h1 class="text-center mb-4">🍜 KULINER LOKAL</h1>

    <div class="row">
      <?php foreach ($kuliner as $k): ?>
        <div class="col-md-4 mb-4">
          <div class="card h-100 shadow-sm">
            <?php if (!empty($k['gambar'])): ?>
              <img src="../uploads/<?= htmlspecialchars($k['gambar']) ?>" 
                   class="card-img-top" 
                   alt="<?= htmlspecialchars($k['nama']) ?>" 
                   style="height:200px; object-fit:cover;">
            <?php else: ?>
              <div class="bg-secondary text-white text-center d-flex align-items-center justify-content-center" style="height:200px;">
                Tidak ada gambar
              </div>
            <?php endif; ?>

            <div class="card-body">
              <h5 class="card-title"><?= htmlspecialchars($k['nama']) ?></h5>
              <p class="card-text"><i class="bi bi-geo-alt"></i> <?= htmlspecialchars($k['lokasi']) ?></p>
              <p class="card-text text-muted"><?= htmlspecialchars(substr($k['deskripsi'], 0, 100)) ?>...</p>
              <p class="card-text"><i class="bi bi-clock"></i> <?= htmlspecialchars($k['jam_buka']) ?></p>
            </div>

            <div class="card-footer bg-white d-flex justify-content-between">
              <button class="btn btn-info btn-sm" 
                      onclick="showMap(<?= $k['latitude'] ?>, <?= $k['longitude'] ?>, '<?= htmlspecialchars($k['nama']) ?>')">
                <i class="bi bi-map"></i> Lihat Lokasi
              </button>
              <a href="kuliner_detail.php?id=<?= $k['id_kuliner'] ?>" class="btn btn-primary btn-sm">
                <i class="bi bi-info-circle"></i> Detail
              </a>
            </div>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  </div>

  <!-- Modal Peta -->
  <div class="modal fade" id="mapModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title">📍 Lokasi Kuliner</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body">
          <div id="map" style="height:400px;"></div>
        </div>
      </div>
    </div>
  </div>

  <!-- Bootstrap & Leaflet -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
  <link rel="stylesheet" href="https://unpkg.com/leaflet/dist/leaflet.css" />
  <script src="https://unpkg.com/leaflet/dist/leaflet.js"></script>

  <script>
    let map;
    function showMap(lat, lng, name) {
      const modal = new bootstrap.Modal(document.getElementById('mapModal'));
      modal.show();

      setTimeout(() => {
        if (!map) {
          map = L.map('map').setView([lat, lng], 15);
          L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '© OpenStreetMap'
          }).addTo(map);
        } else {
          map.setView([lat, lng], 15);
        }

        L.marker([lat, lng]).addTo(map)
          .bindPopup(`<b>${name}</b>`)
          .openPopup();
        map.invalidateSize();
      }, 500);
    }
  </script>
<div class="card-footer text-center text-muted py-2">
                &copy; <?= date('Y') ?> EXFAKTOUR. Semua Hak Dilindungi.
            </div>
</body>
</html>
