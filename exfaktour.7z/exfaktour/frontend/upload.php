<?php
session_start();
require_once "../config/database.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: login_user.php");
    exit;
}

$user_id = $_SESSION['user_id'];

if (isset($_FILES['foto']) && $_FILES['foto']['error'] === UPLOAD_ERR_OK) {
    $folder = "../uploads/";
    if (!is_dir($folder)) mkdir($folder);

    $ext = pathinfo($_FILES['foto']['name'], PATHINFO_EXTENSION);
    $nama_file = "user_" . $user_id . "_" . time() . "." . $ext;
    $target = $folder . $nama_file;

    if (move_uploaded_file($_FILES['foto']['tmp_name'], $target)) {
        $stmt = $pdo->prepare("UPDATE users SET foto = ? WHERE id_user = ?");
        $stmt->execute([$nama_file, $user_id]);
    }
}

header("Location: profil.php");
exit;
?>
