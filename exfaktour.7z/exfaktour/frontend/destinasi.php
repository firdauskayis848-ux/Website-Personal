<?php
require_once "../config/database.php";
$destinasi = $pdo->query("SELECT * FROM destinasi")->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>EXFAKTOUR - Temukan Dunia Disekitarmu</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">

  <!-- Leaflet -->
  <link rel="stylesheet" href="https://unpkg.com/leaflet/dist/leaflet.css" />
  <script src="https://unpkg.com/leaflet/dist/leaflet.js"></script>

  <!-- Leaflet Routing Machine -->
  <link rel="stylesheet" href="https://unpkg.com/leaflet-routing-machine/dist/leaflet-routing-machine.css" />
  <script src="https://unpkg.com/leaflet-routing-machine/dist/leaflet-routing-machine.js"></script>

  <style>
    #map { height: 400px; }
  </style>
</head>
<body class="bg-light">

  <!-- Navbar -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
    <div class="container">
      <a class="navbar-brand fw-bold" href="index.php">EXFAKTOUR </a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav ms-auto">
          <li class="nav-item"><a class="nav-link active" href="index.php">BERANDA</a></li>
          
      </div>
    </div>
  </nav>

  <!-- Konten -->
  <div class="container mt-4">
    <h1 class="text-center mb-4">🏝️ DESTINASI WISATA</h1>

   <div class="row">
<?php foreach ($destinasi as $d): ?>
    <div class="col-md-4 mb-4">
        <div class="card h-100 shadow-sm">
            <?php if (!empty($d['gambar'])): ?>
                <img src="../uploads/<?= htmlspecialchars($d['gambar']) ?>" 
                     class="card-img-top" 
                     alt="<?= htmlspecialchars($d['nama']) ?>" 
                     style="height:200px; object-fit:cover;">
            <?php endif; ?>
            <div class="card-body">
                <h5 class="card-title"><?= htmlspecialchars($d['nama']) ?></h5>
                <p class="card-text"><i class="bi bi-geo-alt"></i> <?= htmlspecialchars($d['lokasi']) ?></p>
                <p class="card-text"><?= htmlspecialchars(substr($d['deskripsi'], 0, 100)) ?>...</p>
                <p class="text-muted">
                    🎫 Rp<?= number_format($d['tiket'], 0, ",", ".") ?> | 
                    ⏰ <?= htmlspecialchars($d['jam_buka']) ?>
                </p>
                <?php if (!empty($d['latitude']) && !empty($d['longitude'])): ?>
                    <p class="small text-muted">
                        🌍 Koordinat: <?= htmlspecialchars($d['latitude']) ?> , <?= htmlspecialchars($d['longitude']) ?>
                    </p>
                <?php endif; ?>
            </div>

            <!-- Tombol Google Maps -->
            <?php if (!empty($d['latitude']) && !empty($d['longitude'])): ?>
                <a href="https://www.google.com/maps?q=<?= $d['latitude'] ?>,<?= $d['longitude'] ?>" 
                   target="_blank" class="btn btn-success m-2">
                  📍 Lihat di Google Maps
                </a>
            <?php endif; ?>

            <!-- Tombol WhatsApp -->
            <?php if (!empty($d['whatsapp'])): 
                // Buat link WA otomatis jika hanya nomor
                $waNumber = preg_replace('/[^0-9]/', '', $d['whatsapp']); // hapus karakter selain angka
                $waLink = (strpos($waNumber, '62') === 0) ? "https://wa.me/$waNumber" : "https://wa.me/62$waNumber";
            ?>
                <a href="<?= $waLink ?>" target="_blank" class="btn btn-outline-success m-2">
                  💬 Pesan Transport
                </a>
            <?php endif; ?>

        </div>
    </div>
<?php endforeach; ?>
</div>
</div>
  </div>

  <!-- Modal Peta -->
 <div class="modal fade" id="mapModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-xl modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">🗺️ Rute Perjalanan</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">

        <!-- Pilihan input -->
        <div class="mb-3">
          <button class="btn btn-sm btn-primary me-2" onclick="useMyLocation()">Gunakan Lokasi Saya</button>
          atau
          <input type="text" id="startLocation" class="form-control d-inline-block w-50" 
                 placeholder="Masukkan lokasi asal (contoh: Jakarta)">
          <button class="btn btn-sm btn-success" onclick="useCustomLocation()">Tampilkan Rute</button>
        </div>

        <div id="map" style="height:500px;"></div>
        <div id="routeInfo" class="mt-3 text-success fw-bold"></div>
      </div>
    </div>
  </div>
</div>

  <!-- Bootstrap JS -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<!-- Routing Machine -->
<link rel="stylesheet" href="https://unpkg.com/leaflet-routing-machine/dist/leaflet-routing-machine.css" />
<script src="https://unpkg.com/leaflet-routing-machine/dist/leaflet-routing-machine.js"></script>
<script>
  let map;
  let routingControl;
  let destLat, destLng, destName;

  function showRoute(lat, lng, name) {
    destLat = lat;
    destLng = lng;
    destName = name;

    const modal = new bootstrap.Modal(document.getElementById('mapModal'));
    modal.show();

    setTimeout(() => {
      if (!map) {
        map = L.map('map').setView([destLat, destLng], 13);
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
          attribution: '© OpenStreetMap'
        }).addTo(map);
      }
      map.invalidateSize();
    }, 500);
  }

  // Fungsi hapus rute lama
  function resetRoute() {
    if (routingControl) {
      map.removeControl(routingControl);
    }
  }

  // Gunakan lokasi GPS user
  function useMyLocation() {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(function(position) {
        const userLat = position.coords.latitude;
        const userLng = position.coords.longitude;
        drawRoute([userLat, userLng], [destLat, destLng]);
      }, function() {
        alert("Tidak bisa mendeteksi lokasi Anda.");
      });
    }
  }

  // Gunakan lokasi manual
  function useCustomLocation() {
    const start = document.getElementById("startLocation").value;
    if (!start) {
      alert("Masukkan lokasi asal terlebih dahulu!");
      return;
    }
    resetRoute();
    routingControl = L.Routing.control({
      waypoints: [
        L.Routing.waypoint(null, start),
        L.latLng(destLat, destLng)
      ],
      geocoder: L.Control.Geocoder.nominatim(),
      routeWhileDragging: false,
      lineOptions: {
        styles: [{ color: 'blue', weight: 5 }]
      }
    }).addTo(map);

    routingControl.on('routesfound', function(e) {
      const route = e.routes[0];
      const jarak = (route.summary.totalDistance / 1000).toFixed(2);
      const waktu = Math.round(route.summary.totalTime / 60);
      document.getElementById("routeInfo").innerHTML = 
        `Jarak: ${jarak} km | Waktu tempuh: ${waktu} menit`;
      map.fitBounds(route.bounds);
    });
  }

  // Gambar rute (fungsi dipakai GPS)
  function drawRoute(startCoords, destCoords) {
    resetRoute();
    routingControl = L.Routing.control({
      waypoints: [
        L.latLng(startCoords[0], startCoords[1]),
        L.latLng(destCoords[0], destCoords[1])
      ],
      routeWhileDragging: false,
      showAlternatives: false,
      lineOptions: {
        styles: [{ color: 'blue', weight: 5 }]
      }
    }).addTo(map);

    routingControl.on('routesfound', function(e) {
      const route = e.routes[0];
      const jarak = (route.summary.totalDistance / 1000).toFixed(2);
      const waktu = Math.round(route.summary.totalTime / 60);
      document.getElementById("routeInfo").innerHTML = 
        `Jarak: ${jarak} km | Waktu tempuh: ${waktu} menit`;
      map.fitBounds(route.bounds);
    });
  }
</script>
 <div class="card-footer text-center text-muted py-2">
                &copy; <?= date('Y') ?> EXFAKTOUR. Semua Hak Dilindungi.
            </div>

</body>
</html>
