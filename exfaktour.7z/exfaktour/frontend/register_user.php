<?php
require_once "../config/database.php";

$message = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $nama = trim($_POST["nama"]);
    $email = trim($_POST["email"]);
    $password = $_POST["password"];
    $confirm = $_POST["confirm"];

    if ($password !== $confirm) {
        $message = "<div class='alert alert-danger text-center'>Password tidak cocok!</div>";
    } else {
        // Cek apakah email sudah terdaftar
        $stmt = $pdo->prepare("SELECT * FROM users WHERE LOWER(email) = LOWER(?)");
        $stmt->execute([$email]);
        $existing = $stmt->fetch();

        if ($existing) {
            $message = "<div class='alert alert-warning text-center'>Email sudah terdaftar!</div>";
        } else {
            // Simpan user baru
            $hashed = password_hash($password, PASSWORD_DEFAULT);
            $insert = $pdo->prepare("INSERT INTO users (nama, email, password) VALUES (?, ?, ?)");
            $insert->execute([$nama, $email, $hashed]);

            $message = "<div class='alert alert-success text-center'>Registrasi berhasil! <a href='login_user.php' class='fw-bold'>Login sekarang</a></div>";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EXFAKTOUR | Daftar Akun</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://unpkg.com/lucide@latest"></script>
    <style>
        body {
            background: linear-gradient(180deg, #f5f7ff, #e3e8ff);
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }
        .register-container {
            background: #fff;
            border-radius: 1rem;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.1);
            width: 420px;
            padding: 2.2rem 2.5rem;
            animation: fadeIn 0.6s ease-in-out;
        }
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(30px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .brand {
            text-align: center;
            font-size: 1.8rem;
            font-weight: 700;
            color: #0d6efd;
        }
        .subtext {
            text-align: center;
            color: #555;
            font-size: 0.9rem;
            margin-bottom: 1.2rem;
        }
        .toggle-eye {
            position: absolute;
            right: 15px;
            top: 70%;
            transform: translateY(-50%);
            cursor: pointer;
            color: #6c757d;
        }
    </style>
</head>
<body>
<div class="register-container">
    <h2 class="brand">EXFAKTOUR</h2>
    <p class="subtext">Temukan dunia sekitarmu dengan EXFAKTOUR</p>

    <h5 class="text-center fw-bold mb-4">Buat Akun Baru</h5>

    <?= $message ?>

    <form method="POST">
        <div class="mb-3">
            <label class="form-label">Nama Lengkap</label>
            <input type="text" name="nama" class="form-control form-control-lg bg-light" placeholder="Masukkan nama lengkap" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Email</label>
            <input type="email" name="email" class="form-control form-control-lg bg-light" placeholder="Masukkan email aktif" required>
        </div>

       <div class="mb-3 position-relative">
  <label class="form-label">Password</label>
  <input type="password" name="password" id="password" class="form-control form-control-lg bg-light" placeholder="Buat password" required>
  <i data-lucide="eye" id="eyeOpen1" class="toggle-eye"></i>
  <i data-lucide="eye-off" id="eyeClose1" class="toggle-eye d-none"></i>
</div>

<div class="mb-3 position-relative">
  <label class="form-label">Konfirmasi Password</label>
  <input type="password" name="confirm" id="confirm" class="form-control form-control-lg bg-light" placeholder="Ulangi password" required>
  <i data-lucide="eye" id="eyeOpen2" class="toggle-eye"></i>
  <i data-lucide="eye-off" id="eyeClose2" class="toggle-eye d-none"></i>
</div>

        <button type="submit" class="btn btn-primary w-100 py-2 fw-bold">Daftar</button>
    </form>

    <div class="text-center mt-3">
        <small>Sudah punya akun? <a href="login_user.php" class="text-primary fw-bold">Masuk di sini</a></small>
    </div>

    <div class="text-center text-muted small mt-3">
        &copy; <?= date('Y') ?> EXFAKTOUR. Semua Hak Dilindungi.
    </div>
</div>

<script src="https://unpkg.com/lucide@latest"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    lucide.createIcons();

    // === Fungsi umum toggle password ===
    function setupToggle(passwordInputId, eyeOpenId, eyeCloseId) {
        const input = document.getElementById(passwordInputId);
        const eyeOpen = document.getElementById(eyeOpenId);
        const eyeClose = document.getElementById(eyeCloseId);

        if (!input || !eyeOpen || !eyeClose) return;

        // Saat klik eye open (lihat password)
        eyeOpen.addEventListener('click', () => {
            input.type = 'text';
            eyeOpen.classList.add('d-none');
            eyeClose.classList.remove('d-none');
        });

        // Saat klik eye close (sembunyikan password)
        eyeClose.addEventListener('click', () => {
            input.type = 'password';
            eyeClose.classList.add('d-none');
            eyeOpen.classList.remove('d-none');
        });
    }

    // === Terapkan ke masing-masing input ===
    setupToggle('password', 'eyeOpen1', 'eyeClose1');
    setupToggle('confirm', 'eyeOpen2', 'eyeClose2');
});
</script>

<div class="card-footer text-center text-muted py-2">
                &copy; <?= date('Y') ?> EXFAKTOUR. Semua Hak Dilindungi.
            </div>
</body>
</html>
