<?php
require_once "../config/database.php";

// Ambil 3 destinasi unggulan
$destinasi = $pdo->query("SELECT * FROM destinasi LIMIT 3")->fetchAll(PDO::FETCH_ASSOC);

// Ambil 3 kuliner unggulan
$kuliner = $pdo->query("SELECT * FROM kuliner LIMIT 3")->fetchAll(PDO::FETCH_ASSOC);

// Ambil 3 hotel unggulan
$hotel = $pdo->query("SELECT * FROM hotel LIMIT 3")->fetchAll(PDO::FETCH_ASSOC);

?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>EXFAKTOUR - Temukan Dunia Disekitarmu</title>
<script src="https://cdn.tailwindcss.com"></script>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
<script src="https://unpkg.com/lucide@latest"></script>
<style>
  body { font-family: 'Inter', sans-serif; }
  .icon-grid-item { @apply flex flex-col items-center text-center p-2 rounded-lg transition-transform transform hover:scale-105; }
  .icon-background { @apply w-14 h-14 bg-gray-200 rounded-full flex items-center justify-center mb-2; }
  .card { @apply bg-white rounded-xl shadow-md overflow-hidden hover:shadow-lg transition-shadow duration-300; }
  .card img { @apply w-full h-48 object-cover; }
</style>
</head>
<script src="https://unpkg.com/lucide@latest"></script>
<script>
  document.addEventListener("DOMContentLoaded", function() {
    lucide.createIcons(); // aktifkan semua ikon lucide
  });
</script>
<body class="bg-gray-50 text-gray-800">

<!-- Header -->
<header class="bg-white shadow-sm sticky top-0 z-50">
  <div class="container mx-auto px-4 py-3 flex justify-between items-center">
    <h1 class="text-2xl font-bold text-gray-900 tracking-wider">EXFAKTOUR</h1>
    <a href="profil.php" class="flex items-center gap-2 px-3 py-2 rounded-full bg-gray-100 hover:bg-gray-200 transition">
      <i data-lucide="user-circle-2" class="w-6 h-6"></i>
      <span class="text-sm font-medium hidden md:block">PROFIL</span>
    </a>
  </div>
</header>

<!-- Main Content -->
<main class="container mx-auto p-4 md:p-6 pb-24">

<!-- Search -->

<!-- Categories -->
<<section class="mb-8">
            <div class="relative">
                <input type="text" placeholder="Cari destinasi, kuliner, atau hotel..." class="w-full pl-12 pr-4 py-3 bg-white border border-gray-300 rounded-full focus:outline-none focus:ring-2 focus:ring-blue-500">
                <div class="absolute left-4 top-1/2 -translate-y-1/2">
                    <i data-lucide="search" class="w-6 h-6 text-gray-400"></i>
                </div>
            </div>
        </section>
      <!-- Categories Section -->
       <section class="mb-10">
  <div class="grid grid-cols-4 md:grid-cols-8 gap-4 text-center">
    
    <!-- Wisata -->
    <a href="destinasi.php" class="icon-grid-item block">
      <div class="icon-background mx-auto mb-1 flex items-center justify-center bg-gray-100 rounded-full w-12 h-12 shadow hover:bg-blue-100 transition">
        <i data-lucide="mountain-snow" class="w-7 h-7 text-gray-600"></i>
      </div>
      <span class="text-xs font-medium text-gray-700">Wisata</span>
    </a>

    <!-- Kuliner -->
    <a href="kuliner.php" class="icon-grid-item block">
      <div class="icon-background mx-auto mb-1 flex items-center justify-center bg-gray-100 rounded-full w-12 h-12 shadow hover:bg-orange-100 transition">
        <i data-lucide="utensils-crossed" class="w-7 h-7 text-gray-600"></i>
      </div>
      <span class="text-xs font-medium text-gray-700">Kuliner</span>
    </a>

    <!-- Hotel -->
    <a href="hotel.php" class="icon-grid-item block">
      <div class="icon-background mx-auto mb-1 flex items-center justify-center bg-gray-100 rounded-full w-12 h-12 shadow hover:bg-green-100 transition">
        <i data-lucide="hotel" class="w-7 h-7 text-gray-600"></i>
      </div>
      <span class="text-xs font-medium text-gray-700">Hotel</span>
    </a>

    <!-- ExCar -->
    <a href="https://wa.me/6281234567890" target="_blank" class="icon-grid-item block">
  <div class="icon-background mx-auto mb-1 flex items-center justify-center bg-gray-100 rounded-full w-12 h-12 shadow hover:bg-yellow-100 transition">
    <i data-lucide="car" class="w-7 h-7 text-gray-600"></i>
  </div>
  <span class="text-xs font-medium text-gray-700">ExCar</span>
</a>

<!-- ExMotor -->
<a href="https://wa.me/6281234567890" target="_blank" class="icon-grid-item block">
  <div class="icon-background mx-auto mb-1 flex items-center justify-center bg-gray-100 rounded-full w-12 h-12 shadow hover:bg-purple-100 transition">
    <i data-lucide="bike" class="w-7 h-7 text-gray-600"></i>
  </div>
  <span class="text-xs font-medium text-gray-700">ExMotor</span>
</a>

<!-- ExBoat -->
<a href="https://wa.me/6281234567890" target="_blank" class="icon-grid-item block">
  <div class="icon-background mx-auto mb-1 flex items-center justify-center bg-gray-100 rounded-full w-12 h-12 shadow hover:bg-teal-100 transition">
    <i data-lucide="ship" class="w-7 h-7 text-gray-600"></i>
  </div>
  <span class="text-xs font-medium text-gray-700">ExBoat</span>
</a>

    <!-- Promo -->
    <a href="promo.php" class="icon-grid-item block">
      <div class="icon-background mx-auto mb-1 flex items-center justify-center bg-gray-100 rounded-full w-12 h-12 shadow hover:bg-pink-100 transition">
        <i data-lucide="ticket-percent" class="w-7 h-7 text-gray-600"></i>
      </div>
      <span class="text-xs font-medium text-gray-700">Promo</span>
    </a>

    <!-- Scan -->
    <a href="scan.php" class="icon-grid-item block">
      <div class="icon-background mx-auto mb-1 flex items-center justify-center bg-gray-100 rounded-full w-12 h-12 shadow hover:bg-indigo-100 transition">
        <i data-lucide="scan-line" class="w-7 h-7 text-gray-600"></i>
      </div>
      <span class="text-xs font-medium text-gray-700">Scan</span>
    </a>

  </div>
</section>

<!-- Pastikan lucide icons aktif -->
<script src="https://unpkg.com/lucide@latest"></script>
<script>
  lucide.createIcons();
</script>

  </div>
  </div>
</section>

<!-- Destinasi Unggulan -->
<div class="bg-white p-4 rounded-lg text-center border-b-2 border-gray-200 mb-6">
    <h3 class="text-2xl font-bold tracking-wide text-gray-800">REKOMENDASI DESTINASI</h3>
</div>

<div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
    <?php foreach ($destinasi as $d): ?>
    <div class="card flex flex-col overflow-hidden">
        <div class="w-full">
            <img src="../uploads/<?= htmlspecialchars($d['gambar']) ?>" alt="<?= htmlspecialchars($d['nama']) ?>" class="object-cover w-full h-56">
        </div>

        <div class="p-5 flex flex-col flex-grow">
            <h5 class="font-bold text-xl mb-2 text-gray-900"><?= htmlspecialchars($d['nama']) ?></h5>
            
            <p class="text-gray-600 mb-3 flex items-center gap-2 text-sm">
                <i data-lucide="map-pin" class="w-4 h-4 text-gray-500"></i>
                <span><?= htmlspecialchars($d['lokasi']) ?></span>
            </p>
            
            <div class="flex items-center mb-4">
                <?php
                  $rating = isset($d['rating']) ? (int)$d['rating'] : 0;
                  for($i = 1; $i <= 5; $i++) {
                      echo $i <= $rating
                          ? '<i data-lucide="star" class="w-5 h-5 text-yellow-400 fill-current"></i>'
                          : '<i data-lucide="star" class="w-5 h-5 text-gray-300"></i>';
                  }
                ?>
                <span class="ml-2 text-sm text-gray-500">(<?= $rating ?>/5)</span>
            </div>
            
            <div class="mt-auto pt-4">
                <a href="destinasi.php?id=<?= $d['id_destinasi'] ?>" class="inline-flex items-center justify-center w-full gap-2 px-4 py-2 bg-blue-600 text-white font-semibold rounded-lg hover:bg-blue-700 transition-colors duration-300 shadow">
                    <span>Lihat Detail</span>
                    <i data-lucide="arrow-right" class="w-4 h-4"></i>
                </a>
            </div>
        </div>
    </div>
    <?php endforeach; ?>
</div>

<!-- Kuliner Unggulan -->
<!-- Destinasi Unggulan -->
<div class="bg-white p-4 rounded-lg text-center border-b-2 border-gray-200 mb-6">
    <h3 class="text-2xl font-bold tracking-wide text-gray-800">REKOMENDASI KULINER</h3>
</div>

<div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
  <?php foreach ($kuliner as $k): ?>
    <div class="card">
      <img src="../uploads/<?= htmlspecialchars($k['gambar']) ?>" 
           alt="<?= htmlspecialchars($k['nama']) ?>" 
           class="object-cover w-full h-56">
      <div class="p-4">
        <h5 class="font-bold text-lg"><?= htmlspecialchars($k['nama']) ?></h5>
        <p class="text-gray-600">
          <i class="bi bi-geo-alt"></i> <?= htmlspecialchars($k['lokasi']) ?>
        </p>

        <!-- Rating -->
        <div class="flex items-center mb-4">
          <?php
            $rating = isset($k['rating']) ? (int)$k['rating'] : 0;
            for ($i = 1; $i <= 5; $i++) {
              echo $i <= $rating
                ? '<i data-lucide="star" class="w-5 h-5 text-yellow-400 fill-current"></i>'
                : '<i data-lucide="star" class="w-5 h-5 text-gray-300"></i>';
            }
          ?>
          <span class="ml-2 text-sm text-gray-500">(<?= $rating ?>/5)</span>
        </div>

        <div class="mt-auto pt-4">
          <a href="kuliner.php?id=<?= urlencode($k['id_kuliner']) ?>" 
             class="inline-flex items-center justify-center w-full gap-2 px-4 py-2 bg-blue-600 text-white font-semibold rounded-lg hover:bg-blue-700 transition-colors duration-300 shadow">
            <span>Lihat Detail</span>
            <i data-lucide="arrow-right" class="w-4 h-4"></i>
          </a>
            </div>
        </div>
    </div>
    <?php endforeach; ?>
</div>
<!-- Destinasi Unggulan -->
<div class="bg-white p-4 rounded-lg text-center border-b-2 border-gray-200 mb-6">
    <h3 class="text-2xl font-bold tracking-wide text-gray-800">REKOMENDASI HOTEL</h3>
</div>

<div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
    <?php foreach ($hotel as $k): ?>
    <div class="card flex flex-col overflow-hidden">
        <div class="w-full">
            <img src="../uploads/<?= htmlspecialchars($k['foto']) ?>" alt="<?= htmlspecialchars($k['nama_hotel']) ?>" class="object-cover w-full h-56">
        </div>

        <div class="p-5 flex flex-col flex-grow">
            <h5 class="font-bold text-xl mb-2 text-gray-900"><?= htmlspecialchars($k['nama_hotel']) ?></h5>
            
            <p class="text-gray-600 mb-3 flex items-center gap-2 text-sm">
                <i data-lucide="map-pin" class="w-4 h-4 text-gray-500"></i>
                <span><?= htmlspecialchars($k['lokasi']) ?></span>
            </p>
            
            <div class="flex items-center mb-4">
                <?php
                  $rating = isset($k['rating']) ? (int)$k['rating'] : 0;
                  for($i = 1; $i <= 5; $i++) {
                      echo $i <= $rating
                          ? '<i data-lucide="star" class="w-5 h-5 text-yellow-400 fill-current"></i>'
                          : '<i data-lucide="star" class="w-5 h-5 text-gray-300"></i>';
                  }
                ?>
                <span class="ml-2 text-sm text-gray-500">(<?= $rating ?>/5)</span>
            </div>
            
            <div class="mt-auto pt-4">
                <a href="hotel.php?id=<?= $k['id_hotel'] ?>" class="inline-flex items-center justify-center w-full gap-2 px-4 py-2 bg-blue-600 text-white font-semibold rounded-lg hover:bg-blue-700 transition-colors duration-300 shadow">
                    <span>Lihat Detail</span>
                    <i data-lucide="arrow-right" class="w-4 h-4"></i>
                </a>
            </div>
        </div>
    </div>
    <?php endforeach; ?>
</div>

</main>

<script>
  document.addEventListener("DOMContentLoaded", function() {
    lucide.createIcons();
  });
</script>
<div class="card-footer text-center text-muted py-2">
                &copy; <?= date('Y') ?> EXFAKTOUR. Semua Hak Dilindungi.
            </div>
</body>
</html>
