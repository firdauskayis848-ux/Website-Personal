<?php
session_start();
require_once "../config/database.php";

// Cek apakah user sudah login
if (!isset($_SESSION['user_id'])) {
    header("Location: login_user.php");
    exit;
}

$id_user = $_SESSION['user_id'];
$message = "";

// Ambil data user dari database
$stmt = $pdo->prepare("SELECT * FROM users WHERE id_user = ?");
$stmt->execute([$id_user]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

// Update profil
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_profile'])) {
    $nama = trim($_POST['nama']);
    $email = trim($_POST['email']);

    // Upload foto baru jika ada
    $fotoName = $user['foto'];
    if (!empty($_FILES['foto']['name'])) {
        $targetDir = "uploads/";
        if (!is_dir($targetDir)) mkdir($targetDir, 0777, true);

        $fotoName = time() . "_" . basename($_FILES["foto"]["name"]);
        $targetFile = $targetDir . $fotoName;

        if (move_uploaded_file($_FILES["foto"]["tmp_name"], $targetFile)) {
            // Hapus foto lama jika ada
            if (!empty($user['foto']) && file_exists($targetDir . $user['foto'])) {
                unlink($targetDir . $user['foto']);
            }
        } else {
            $message = "❌ Gagal mengupload foto!";
        }
    }

    // Update data profil
    $stmt = $pdo->prepare("UPDATE users SET nama = ?, email = ?, foto = ? WHERE id_user = ?");
    $stmt->execute([$nama, $email, $fotoName, $id_user]);

    $_SESSION['nama_user'] = $nama;
    $message = "✅ Profil berhasil diperbarui!";
}

// Ubah password
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['change_password'])) {
    $password_lama = $_POST['password_lama'];
    $password_baru = $_POST['password_baru'];
    $konfirmasi = $_POST['konfirmasi_password'];

    if (!password_verify($password_lama, $user['password'])) {
        $message = "❌ Password lama salah!";
    } elseif ($password_baru !== $konfirmasi) {
        $message = "❌ Konfirmasi password tidak cocok!";
    } else {
        $hashed = password_hash($password_baru, PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("UPDATE users SET password = ? WHERE id_user = ?");
        $stmt->execute([$hashed, $id_user]);
        $message = "✅ Password berhasil diubah!";
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Edit Profil - EXFAKTOUR</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gradient-to-br from-blue-50 to-indigo-100 min-h-screen flex justify-center py-10">
  <div class="bg-white shadow-xl rounded-2xl p-8 w-full max-w-2xl">
    <h1 class="text-2xl font-bold text-center mb-4 text-indigo-700">Edit Profil</h1>

    <?php if (!empty($message)): ?>
      <div class="text-center mb-4 p-3 rounded-lg 
                  <?= str_contains($message, '✅') ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700' ?>">
        <?= htmlspecialchars($message) ?>
      </div>
    <?php endif; ?>

    <!-- FORM UPDATE PROFIL -->
    <form method="POST" enctype="multipart/form-data" class="space-y-4">
      <input type="hidden" name="update_profile" value="1">

      <div>
        <label class="block text-gray-700 font-semibold">Nama Lengkap</label>
        <input type="text" name="nama" value="<?= htmlspecialchars($user['nama']) ?>" required
               class="w-full border rounded-lg px-3 py-2 focus:ring-2 focus:ring-indigo-500">
      </div>

      <div>
        <label class="block text-gray-700 font-semibold">Email</label>
        <input type="email" name="email" value="<?= htmlspecialchars($user['email']) ?>" required
               class="w-full border rounded-lg px-3 py-2 focus:ring-2 focus:ring-indigo-500">
      </div>

      <div>
        <label class="block text-gray-700 font-semibold">Foto Profil</label>
        <?php if (!empty($user['foto'])): ?>
          <img src="uploads/<?= htmlspecialchars($user['foto']) ?>" alt="Foto Profil" class="w-24 h-24 rounded-full mb-2">
        <?php else: ?>
          <p class="text-gray-500 mb-2">Belum ada foto.</p>
        <?php endif; ?>
        <input type="file" name="foto" accept="image/*"
               class="block w-full text-sm border rounded-lg bg-gray-50 focus:ring-2 focus:ring-indigo-500">
      </div>

      
    <hr class="my-8 border-gray-300">

    <!-- FORM UBAH PASSWORD -->
    <h2 class="text-xl font-semibold text-indigo-700 text-center mb-4">Ubah Password</h2>
    <form method="POST" class="space-y-4">
      <input type="hidden" name="change_password" value="1">

      <div>
        <label class="block text-gray-700 font-semibold">Password Lama</label>
        <input type="password" name="password_lama" required
               class="w-full border rounded-lg px-3 py-2 focus:ring-2 focus:ring-indigo-500">
      </div>

      <div>
        <label class="block text-gray-700 font-semibold">Password Baru</label>
        <input type="password" name="password_baru" required
               class="w-full border rounded-lg px-3 py-2 focus:ring-2 focus:ring-indigo-500">
      </div>

      <div>
        <label class="block text-gray-700 font-semibold">Konfirmasi Password Baru</label>
        <input type="password" name="konfirmasi_password" required
               class="w-full border rounded-lg px-3 py-2 focus:ring-2 focus:ring-indigo-500">
      </div>

      <div class="flex justify-end mt-4">
        <button type="submit" class="bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded-lg">Ubah Password</button>
      </div>
      <div class="flex justify-between mt-6">
        <a href="index.php" class="bg-gray-400 hover:bg-gray-500 text-white px-4 py-2 rounded-lg">Kembali</a>
        <button type="submit" class="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-lg">Simpan Perubahan</button>
      </div>
    </form>

    </form>
  </div>
  <div class="card-footer text-center text-muted py-2">
                &copy; <?= date('Y') ?> EXFAKTOUR. Semua Hak Dilindungi.
            </div>
</body>
</html>
