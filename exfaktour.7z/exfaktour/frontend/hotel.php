<?php
require_once "../config/database.php";

// Ambil semua data hotel
$hotels = $pdo->query("SELECT * FROM hotel ORDER BY id_hotel DESC")->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Daftar Hotel - EXFAKTOUR</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
  <style>
    body { background: #f8f9fa; font-family: 'Poppins', sans-serif; }
    .hotel-card { border-radius: 15px; overflow: hidden; box-shadow: 0 6px 15px rgba(0,0,0,0.1); transition: all 0.3s ease; }
    .hotel-card:hover { transform: translateY(-5px); box-shadow: 0 10px 25px rgba(0,0,0,0.15); }
    .hotel-img { height: 220px; object-fit: cover; }
    .price { font-weight: 700; color: #007bff; }
  </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
  <div class="container">
    <a class="navbar-brand fw-bold" href="index.php">EXFAKTOUR</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ms-auto">
        <li class="nav-item"><a class="nav-link active" href="index.php">BERANDA</a></li>
      </ul>
    </div>
  </div>
</nav>

<div class="container py-5">
  <h2 class="text-center fw-bold mb-4">🏨DAFTAR HOTEL</h2>

  <div class="row g-4">
    <?php if (count($hotels) > 0): ?>
      <?php foreach ($hotels as $hotel): ?>
        <div class="col-md-4">
          <div class="card hotel-card">
            <?php if (!empty($hotel['foto']) && file_exists("../uploads/".$hotel['foto'])): ?>
              <img src="../uploads/<?= htmlspecialchars($hotel['foto']) ?>" class="card-img-top hotel-img" alt="<?= htmlspecialchars($hotel['nama_hotel']) ?>">
            <?php else: ?>
              <img src="../assets/default-hotel.jpg" class="card-img-top hotel-img" alt="No Image">
            <?php endif; ?>

            <div class="card-body">
              <h5 class="card-title"><?= htmlspecialchars($hotel['nama_hotel']) ?></h5>
              <p class="text-muted"><?= htmlspecialchars($hotel['lokasi']) ?></p>
              <p class="card-text small"><?= nl2br(substr($hotel['deskripsi'], 0, 100)) ?>...</p>
              <p class="price">Rp <?= number_format($hotel['harga_per_malam'],0,',','.') ?>/malam</p>
              <p>⭐ <?= number_format($hotel['rating'],1) ?></p>
            </div>

            <div class="card-footer d-flex flex-column gap-2">
              <?php if (!empty($hotel['whatsapp'])): 
                $waNumber = preg_replace('/[^0-9]/','',$hotel['whatsapp']);
                if (substr($waNumber,0,1) === '0') $waNumber = '62'.substr($waNumber,1);
                $waLink = "https://wa.me/$waNumber";
              ?>
                <a href="<?= $waLink ?>" target="_blank" class="btn btn-success btn-sm w-100">💬 Chat via WhatsApp</a>
              <?php endif; ?>

              <?php if (!empty($hotel['latitude']) && !empty($hotel['longitude'])): ?>
                <a href="https://www.google.com/maps?q=<?= $hotel['latitude'] ?>,<?= $hotel['longitude'] ?>" target="_blank" class="btn btn-outline-primary btn-sm w-100">
                  📍 Lihat di Maps
                </a>
              <?php endif; ?>
            </div>

          </div>
        </div>
      <?php endforeach; ?>
    <?php else: ?>
      <div class="text-center text-muted">Belum ada data hotel.</div>
    <?php endif; ?>
  </div>
</div>

<div class="card-footer text-center text-muted py-2">
  &copy; <?= date('Y') ?> EXFAKTOUR. Semua Hak Dilindungi.
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
